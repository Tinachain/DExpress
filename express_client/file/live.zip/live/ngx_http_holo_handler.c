#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>

ngx_int_t 
ngx_http_holo_handler(ngx_http_request_t *r)
{
    u_char                    *last, *buf, *p;
    off_t                      len;
    size_t                     root;
    ngx_int_t                  rc;
    ngx_uint_t                 level;
    ngx_str_t                  path, value, file;
    ngx_log_t                 *log;
    ngx_buf_t                 *b;
    ngx_chain_t               *out;
    ngx_open_file_info_t       of;
    ngx_http_core_loc_conf_t  *clcf;
    ngx_http_live_m3u8_conf_t *hlcf;
    ngx_int_t                  i, j, start, n;
    time_t                     now;
	
    len =0;	
	
    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }   

    last = ngx_http_map_uri_to_path(r, &path, &root, 0);
    if (last == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    last -= 6; 

    log = r->connection->log;
    clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);

    path.len = last - path.data;

    if (r->args.len == 0) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "should provide \"starttime\" and \"length\" parameter");
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "starttime", 9, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "should provide \"starttime\" parameter");
        return NGX_HTTP_BAD_REQUEST;        
    }
    
    if (value.len != 15) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "\"starttime\" \"%V\" format error", &value);
        return NGX_HTTP_BAD_REQUEST;        
    }
    
    now = ngx_time();
    start = ngx_http_live_m3u8_timestamp(&value, hlcf->time_offset);
    if (start == NGX_ERROR || start >= now) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "\"starttime\" \"%V\" format error", &value);
        return NGX_HTTP_BAD_REQUEST;        
    }

    if (ngx_http_arg(r, (u_char *) "length", 6, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "should provide \"len\" parameter");
        return NGX_HTTP_BAD_REQUEST;        
    }

    n = ngx_atoi(value.data, value.len);
    if (n == 0) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "invalid \"length\" parameter");
        return NGX_HTTP_BAD_REQUEST;        
    }
    
    if (n > hlcf->max_length) {
        n = hlcf->max_length;
    }

    buf = ngx_palloc(r->pool, n * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (buf == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    rc = ngx_http_live_m3u8_get_index(r, &path, start, &hlcf->holo_stream, n, NGX_LIVE, buf);
    if (rc == NGX_ERROR) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    for (i = 0, j = 0, p = buf; i < n; i++) {
        if (*p != 0x20 /* space */) {
            j++;
        }
        
        p += NGX_LIVE_M3U8_INDEX_LINE_SIZE;
    }
    
    if (j == 0) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;        
    }
 
    out = ngx_palloc(r->pool, j * sizeof(ngx_chain_t));
    if (out == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    j = 0;
    for (i = 0, p = buf; i < n; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
        
        if (*p == 0x20 /* space */) {
            continue;
        }
        
        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (last == NULL) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
            return NGX_HTTP_INTERNAL_SERVER_ERROR;        
        }
        

        value.data = p;
        value.len = last - p;

        file.data = ngx_pcalloc(r->pool, path.len + value.len + 1); 
        if (file.data == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;        
        }
        last = file.data;
        last = ngx_copy(last, path.data, path.len);
        last = ngx_copy(last, value.data, value.len);
        file.len = last - file.data;
        *last = 0;

        ngx_memzero(&of, sizeof(ngx_open_file_info_t));
    
        of.read_ahead = clcf->read_ahead;
        of.directio = clcf->directio;
        of.valid = clcf->open_file_cache_valid;
        of.min_uses = clcf->open_file_cache_min_uses;
        of.errors = clcf->open_file_cache_errors;
        of.events = clcf->open_file_cache_events;
    
        if (ngx_http_set_disable_symlinks(r, clcf, &file, &of) != NGX_OK) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }
        
        ngx_log_debug1(NGX_LOG_DEBUG_HTTP, log, 0, "append \"%s\" file", file.data);
        if (ngx_open_cached_file(clcf->open_file_cache, &file, &of, r->pool) != NGX_OK)
        {
            switch (of.err) {
    
            case 0:
                return NGX_HTTP_INTERNAL_SERVER_ERROR;
    
            case NGX_ENOENT:
            case NGX_ENOTDIR:
            case NGX_ENAMETOOLONG:
    
                level = NGX_LOG_ERR;
                rc = NGX_HTTP_NOT_FOUND;
                break;
    
            case NGX_EACCES:
    #if (NGX_HAVE_OPENAT)
            case NGX_EMLINK:
            case NGX_ELOOP:
    #endif
    
                level = NGX_LOG_ERR;
                rc = NGX_HTTP_FORBIDDEN;
                break;
    
            default:
    
                level = NGX_LOG_CRIT;
                rc = NGX_HTTP_INTERNAL_SERVER_ERROR;
                break;
            }
    
            if (rc != NGX_HTTP_NOT_FOUND || clcf->log_not_found) {
                ngx_log_error(level, log, of.err,
                              "%s \"%s\" failed", of.failed, file.data);
                /*printf("%s\n", file.data);*/
            }
            
            if (rc == NGX_HTTP_NOT_FOUND) {
                continue;
            }
    
            return rc;
        }
    
        if (!of.is_file) {
    
            if (ngx_close_file(of.fd) == NGX_FILE_ERROR) {
                ngx_log_error(NGX_LOG_ALERT, log, ngx_errno, ngx_close_file_n " \"%s\" failed", file.data);
            }
    
            return NGX_DECLINED;
        }
    
        b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
        if (b == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        b->file = ngx_pcalloc(r->pool, sizeof(ngx_file_t));
        if (b->file == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }
        len += of.size;
        b->file_pos = 0;
        b->file_last = of.size;
    
        b->in_file = 1;
        b->last_buf = 0;
        b->last_in_chain = 0;
    
        b->file->fd = of.fd;
        b->file->name = file;
        b->file->log = log;
        b->file->directio = of.is_directio;
  
        out[j].buf = b; 
        out[j].next = &out[j + 1];
        j++;
    }
    
    if (j == 0) {
        return NGX_HTTP_NOT_FOUND;
    }

    out[j - 1].buf->last_buf = 1;
    out[j - 1].buf->last_in_chain = 1;
    out[j - 1].next = NULL;

    r->allow_ranges = 1;

    r->root_tested = !r->error_page;

    log->action = "sending holo to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = len;
    r->headers_out.last_modified_time = of.mtime;

    if (ngx_http_set_etag(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    return ngx_http_output_filter(r, out);
}
