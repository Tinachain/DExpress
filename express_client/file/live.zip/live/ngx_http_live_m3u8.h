#ifndef _NGX_HTTP_LIVE_M3U8_H_INCLUDED_
#define _NGX_HTTP_LIVE_M3U8_H_INCLUDED_


#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>

//#define NGX_LIVE_M3U8_INDEX_LINE_SIZE 40
#define NGX_LIVE_M3U8_INDEX_LINE_SIZE 300
#define NGX_LIVE_MEU8_MAX_TIME        (7 * 86400)

//新增的返回信息（标识m3u8存在）
#define NGX_EXIST_M3U8        9999
#define NGX_REVIEW  0
#define NGX_LIVE    1 

typedef struct {
    time_t                     default_length;
    ngx_int_t                  time_offset;
    time_t                     segment_duration;
    ngx_hash_t                 metas;
    ngx_array_t               *metas_keys;
    ngx_hash_t                 streams;
    ngx_array_t               *streams_keys;
    ngx_str_t                  holo_stream;
    ngx_str_t                  logo_stream;
	ngx_str_t                  logo_resolution;
    ngx_str_t                  share_resp;
    ngx_str_t                  origin;
    ngx_str_t                  localhost;
    time_t                     max_length;
	ngx_str_t                  local_addr;
	
    ngx_flag_t                 advertising_titles;
    ngx_array_t               *advertisements;
    
    ngx_flag_t                 dynamic_offset;
    ngx_uint_t                 segments_per_playlist;
    ngx_shm_zone_t     		  *shm_zone;
    ngx_flag_t                 live_mode;
    ngx_flag_t                 hls2mp4_logo;
    ngx_str_t                  mergemp4_local_addr;
} ngx_http_live_m3u8_conf_t;


ngx_int_t ngx_http_holo_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_review_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_share_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_share_jpg_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_get_pic_handler(ngx_http_request_t *r);

ngx_int_t ngx_http_share_multi_map_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_share_m3u8_handler(ngx_http_request_t *r);
ngx_int_t ngx_http_timeshift_handler(ngx_http_request_t *r);
char * ngx_http_live_m3u8_timeshift_zone(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);

ngx_int_t ngx_http_live_m3u8_timestamp(ngx_str_t *src, ngx_int_t offset);
ngx_int_t ngx_http_live_m3u8_get_index(ngx_http_request_t *r, ngx_str_t *path, time_t time, ngx_str_t *stream, ngx_int_t duration, ngx_int_t type, u_char *buf);
ngx_int_t ngx_http_live_m3u8_get_index_for_get_pic(ngx_http_request_t *r, ngx_str_t *path, time_t time, ngx_str_t *stream, u_char *buf);

void * ngx_http_test_stream_type(ngx_http_request_t *r, ngx_hash_t *streams_hash, ngx_str_t *stream);
ngx_int_t ngx_http_live_m3u8_build_index(ngx_http_request_t *r, ngx_open_file_info_t *of, ngx_str_t *args, ngx_buf_t *b);

ngx_int_t ngx_http_live_m3u8_build_playlist(ngx_http_request_t *r, ngx_buf_t *b, ngx_str_t *stream, time_t start, time_t duration, ngx_int_t share);
ngx_int_t ngx_http_live_m3u8_build_live_playlist(ngx_http_request_t *r, ngx_buf_t *b, ngx_str_t *stream, time_t start, time_t duration, ngx_uint_t sequence);

extern ngx_module_t  ngx_http_live_m3u8_module;

#endif /* _NGX_HTTP_LIVE_M3U8_H_INCLUDED_ */
