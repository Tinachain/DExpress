#!/usr/bin/env python

import os,sys,urllib,urllib2,uuid

def execute_cmd(cmd):
	ret = os.system(cmd)
	ret >>= 8
	return ret

def notify(uuid_str,state,zipfile_uri,notify_url):
	try:
		msg = ''
		if state == 1:
			msg = 'success'
		else:
			msg = 'failed'
			
		dict_t = {}
		dict_t["keyvalue"] = 1
		dict_t["state"] = state
		dict_t["uuid"] = uuid_str
		dict_t["compress_url"] = zipfile_uri
		dict_t["stateinfo"] = msg
	
		params = urllib.urlencode(dict_t)
		fd = urllib.urlopen(notify_url, params)
		resp = fd.read()
		print resp
	except Exception,e:
		print e
	
def main():
	if len(sys.argv) != 6:
		print 'bad args'
		return 1
	cmd = "echo start zip >> /home/otvcloud/d.t"
	execute_cmd(cmd)
	getpic_dir = "/usr/local/bin"
	try:	
		uuid_str = sys.argv[1]
		notify_url = urllib.unquote(sys.argv[2])
		m3u8_file = sys.argv[3]
		ipport =  sys.argv[4]
		ts_basedir = sys.argv[5]
		zipfile_uri = ''
	
		zip_name = uuid.uuid1()
		cmd = "cd %s && zip %s.zip *.m3u8" % (os.path.dirname(m3u8_file), zip_name)
		if execute_cmd(cmd) != 0:
			print cmd
			#return 2
		
		sub_m3u8_list = []
#######		
		fh_r = open(m3u8_file ,'r')
		lines = fh_r.readlines()
		fh_w = open(m3u8_file ,'w')

		for  line in  lines:
			if  '.m3u8' in  line:
				( sub_m3u8_dir , sub_m3u8_name ) =  os.path.split( line.rstrip())
				m3u8_dir = os.path.dirname(m3u8_file) + '/'+ sub_m3u8_name
				if os.path.exists(m3u8_dir) and os.path.isfile(m3u8_dir):
					sub_m3u8_list.append( line.rstrip() )
					sub_m3u8_name += '\r\n'
					fh_w.write( sub_m3u8_name )
					continue
				else:
					fh_r.close()
					fh_w.close()
					notify(uuid_str, 0, zipfile_uri, notify_url)
					return 100
			else:
				fh_w.write(line);
		fh_r.close()	
		fh_w.close()			
#######
		if  not sub_m3u8_list :
			notify(uuid_str, 0, zipfile_uri, notify_url)
			return 100
			
		if	not ts_basedir.endswith('/'):
			ts_basedir += '/'

		ts_dir = ''

		for m3u8_item in sub_m3u8_list:
			ts_flag = 0
			( sub_m3u8_dir , sub_m3u8_name ) =  os.path.split( m3u8_item)
			m3u8_dir = os.path.dirname(m3u8_file) + '/'+ sub_m3u8_name
			
			fh = open(m3u8_dir ,'r')
			for  line in  fh.readlines(): 
				if  '.ts' in  line:
					ts_dir = ts_basedir +  '/' + line.rstrip()

					ts_flag = 1 
					if os.path.exists(ts_dir) and os.path.isfile(ts_dir):
						continue
					else:
						fh.close()
						zipfile_uri = "http://%s/zipdir/%s/%s.zip" % (ipport, uuid_str, zip_name)				
						notify(uuid_str, 0, zipfile_uri, notify_url)	
						print 'ts_dir is errror'
						return 100 
			fh.close()						
			if ts_flag == 0:
				fh.close()
				zipfile_uri = "http://%s/zipdir/%s/%s.zip" % (ipport, uuid_str, zip_name)
				notify(uuid_str, 0, zipfile_uri, notify_url)
				print 'ts_dir is errror'
				return 100

		getpic_flag = 0		
		for m3u8_item in sub_m3u8_list:
			( sub_m3u8_dir , sub_m3u8_name ) =  os.path.split( m3u8_item)
			m3u8_dir = os.path.dirname(m3u8_file) + '/'+ sub_m3u8_name
		#	ts_basedir +=  '/' + sub_m3u8_dir
			cmd = "cd %s && zip -0 -g -r %s/%s.zip `grep \".ts\" %s|awk '{sub(/\r$/,\"\");print}'` && cd -" % (ts_basedir  , os.path.dirname(m3u8_file), zip_name, m3u8_dir)
			if execute_cmd(cmd) != 0:
				print cmd
				continue

			if getpic_flag == 0:
				ts_list = []
				with open( m3u8_dir ,'r') as fh:
					for line in fh.readlines():
						if '.ts' in line:
							ts_list.append(os.path.join( ts_basedir , line.rstrip() ))
				fh.close()
				
				ts_len = len(ts_list)
				cmd1 = "echo 'ts_len = %d' >> /home/otvcloud/d.t" %( ts_len )
				execute_cmd(cmd1)

				if ts_len > 8:
					ts_step = ts_len/7
					for num in range( 0 , ts_len-1   , ts_step):
						cmd = "cd %s && %s/getpic %s %s_%d.jpg && zip -g %s/%s.zip  %s_%d.jpg && cd -" % ( os.path.dirname(m3u8_file), getpic_dir,  ts_list[num] , uuid_str , num ,os.path.dirname(m3u8_file) ,zip_name , uuid_str , num)
						if execute_cmd(cmd) != 0:
							print cmd
						if num /ts_step >= 7 - 1 :
							cmd = "cd %s && %s/getpic %s %s_%d.jpg && zip -g %s/%s.zip  %s_%d.jpg && cd -" % ( os.path.dirname(m3u8_file),getpic_dir,  ts_list[ts_len-1] , uuid_str , ts_len-1 ,os.path.dirname(m3u8_file) ,zip_name , uuid_str , ts_len-1)
							if execute_cmd(cmd) != 0:
								print cmd
							break
						cmd1 = "echo '%s' >> /home/otvcloud/d.t" %( cmd )
					        execute_cmd(cmd1)

				elif ts_len <= 0 :
					continue
				else:
					ts_step = 1
					for num in range( 0 , ts_len-1   , ts_step):
						cmd = "cd %s && %s/getpic %s %s_%d.jpg && zip -0 -g %s/%s.zip %s_%d.jpg && cd -" % ( os.path.dirname(m3u8_file) , getpic_dir,  ts_list[num] , uuid_str , num  ,os.path.dirname(m3u8_file) ,zip_name , uuid_str , num )
						if execute_cmd(cmd) != 0:
							print cmd
				getpic_flag =1
			
		zipfile_uri = "http://%s/zipdir/%s/%s.zip" % (ipport, uuid_str, zip_name)
		
		notify(uuid_str, 1, zipfile_uri, notify_url)
		
	except Exception,e:
		fh.close()
		print e
		notify(uuid_str, 0, zipfile_uri, notify_url)
		return 100
	
	print 'success'
	
	return 0 			

if __name__ == '__main__':
	main()
	 
