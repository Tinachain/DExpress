
#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>

static char *ngx_http_live_m3u8_holo(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_review(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_share(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_share_jpg(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_get_pic(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_share_m3u8(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_share_multi_map(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_live_m3u8_timeshift(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_streams_slot(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_merge_streams(ngx_conf_t *cf, ngx_array_t **keys, ngx_hash_t *streams_hash, ngx_array_t **prev_keys, ngx_hash_t *prev_streams_hash, ngx_str_t *default_streams);
static ngx_int_t ngx_http_set_default_streams(ngx_conf_t *cf, ngx_array_t **streams, ngx_str_t *default_streams);
static char *ngx_http_time_offset(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static void *ngx_http_live_m3u8_create_conf(ngx_conf_t *cf);
static char *ngx_http_live_m3u8_merge_conf(ngx_conf_t *cf, void *parent, void *child);
ngx_int_t ngx_http_share_multi_map_handler(ngx_http_request_t *r);

static ngx_str_t  ngx_http_default_streams[] = {
    ngx_string("1400"),
    ngx_null_string
};

static ngx_str_t  ngx_http_default_metas[] = {
    ngx_string("index"),
    ngx_null_string
};

static ngx_command_t  ngx_http_live_m3u8_commands[] = {

    { ngx_string("live_default_length"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_sec_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, default_length),
      NULL },

    { ngx_string("live_meta_list"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_1MORE,
      ngx_http_streams_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, metas_keys),
      &ngx_http_default_metas[0] },

    { ngx_string("live_stream_list"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_1MORE,
      ngx_http_streams_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, streams_keys),
      &ngx_http_default_streams[0] },

    { ngx_string("live_time_offset"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_http_time_offset,
      NGX_HTTP_LOC_CONF_OFFSET,
      0,
      NULL },

    { ngx_string("live_segment_duration"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_sec_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, segment_duration),
      NULL },

    { ngx_string("live_advertising_titles"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_FLAG,
      ngx_conf_set_flag_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, advertising_titles),
      NULL },

    { ngx_string("live_add_advertisement"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE2,
      ngx_conf_set_keyval_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, advertisements),
      NULL },

    { ngx_string("live_holo_stream"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, holo_stream),
      NULL },
      
    { ngx_string("live_share_logo_stream"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, logo_stream),
      NULL },
	
	{ ngx_string("live_getpic_local_addr"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, local_addr),
      NULL },

	{ ngx_string("live_share_logo_resolution"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, logo_resolution),
      NULL },

    { ngx_string("share_origin_host"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, origin),
      NULL },

    { ngx_string("live_m3u8_local_host"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, localhost),
      NULL },

    { ngx_string("share_response"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, share_resp),
      NULL },

    { ngx_string("live_max_length"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_sec_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, max_length),
      NULL },
    { ngx_string("hls2mp4_log_flag"),
        NGX_HTTP_MAIN_CONF | NGX_HTTP_SRV_CONF | NGX_HTTP_LOC_CONF|NGX_CONF_FLAG,
      ngx_conf_set_flag_slot,
      NGX_HTTP_LOC_CONF_OFFSET, 
      offsetof(ngx_http_live_m3u8_conf_t, hls2mp4_logo),
      NULL },

    { ngx_string("holo"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_holo,
      0,
      0,
      NULL },

    { ngx_string("review"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_review,
      0,
      0,
      NULL },

    { ngx_string("live"),
      NGX_HTTP_LOC_CONF|NGX_CONF_FLAG,
      ngx_conf_set_flag_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, live_mode),
      NULL },

    { ngx_string("share"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_share,
      0,
      0,
      NULL },

    { ngx_string("share_jpg"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_share_jpg,
      0,
      0,
      NULL },

	{ ngx_string("get_pic"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_get_pic,
      0,
      0,
      NULL },

    { ngx_string("share_piczip"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_share_multi_map,
      0,
      0,
      NULL },

    { ngx_string("share_m3u8"),
      NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
      ngx_http_live_m3u8_share_m3u8,
      0,
      0,
      NULL },

    { ngx_string("timeshift_zone"),
      NGX_HTTP_MAIN_CONF|NGX_CONF_TAKE1,
      ngx_http_live_m3u8_timeshift_zone,
      0,
      0,
      NULL },

    { ngx_string("timeshift_segments_per_playlist"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_num_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, segments_per_playlist),
      NULL },

    { ngx_string("timeshift"),
      NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_http_live_m3u8_timeshift,
      NGX_HTTP_LOC_CONF_OFFSET,
      0,
      NULL },

    { ngx_string("share_dynamic_offset"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_FLAG,
      ngx_conf_set_flag_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, dynamic_offset),
      NULL },
    { ngx_string("live_mergemp4_local_addr"),
      NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
      ngx_conf_set_str_slot,
      NGX_HTTP_LOC_CONF_OFFSET,
      offsetof(ngx_http_live_m3u8_conf_t, mergemp4_local_addr),
      NULL },
      ngx_null_command
};


static ngx_http_module_t  ngx_http_live_m3u8_module_ctx = {
    NULL,                          /* preconfiguration */
    NULL,                          /* postconfiguration */

    NULL,                          /* create main configuration */
    NULL,                          /* init main configuration */

    NULL,                          /* create server configuration */
    NULL,                          /* merge server configuration */

    ngx_http_live_m3u8_create_conf,/* create location configuration */
    ngx_http_live_m3u8_merge_conf  /* merge location configuration */
};


ngx_module_t  ngx_http_live_m3u8_module = {
    NGX_MODULE_V1,
    &ngx_http_live_m3u8_module_ctx,/* module context */
    ngx_http_live_m3u8_commands,   /* module directives */
    NGX_HTTP_MODULE,               /* module type */
    NULL,                          /* init master */
    NULL,                          /* init module */
    NULL,                          /* init process */
    NULL,                          /* init thread */
    NULL,                          /* exit thread */
    NULL,                          /* exit process */
    NULL,                          /* exit master */
    NGX_MODULE_V1_PADDING
};


static char *
ngx_http_live_m3u8_holo(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_holo_handler;

    return NGX_CONF_OK;
}


static char *
ngx_http_live_m3u8_review(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_review_handler;

    return NGX_CONF_OK;
}


static char *
ngx_http_live_m3u8_share(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_share_handler;

    return NGX_CONF_OK;
}


static char *
ngx_http_live_m3u8_share_jpg(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_share_jpg_handler;

    return NGX_CONF_OK;
}



static char *
ngx_http_live_m3u8_get_pic(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_get_pic_handler;

    return NGX_CONF_OK;
}


static char *
ngx_http_live_m3u8_share_multi_map(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_share_multi_map_handler;

    return NGX_CONF_OK;
}



static char *
ngx_http_live_m3u8_share_m3u8(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_share_m3u8_handler;

    return NGX_CONF_OK;
}


static char *
ngx_http_live_m3u8_timeshift(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_core_loc_conf_t  *clcf;
    ngx_str_t                 *value;
    ngx_shm_zone_t            *shm_zone;
    ngx_http_live_m3u8_conf_t *hlcf = conf;

    clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_timeshift_handler;

    value = cf->args->elts;

    shm_zone = ngx_shared_memory_add(cf, &value[1], 0,
                                     &ngx_http_live_m3u8_module);
    if (shm_zone == NULL) {
        return NGX_CONF_ERROR;
    }
    
    hlcf->shm_zone = shm_zone;

    return NGX_CONF_OK;
}


static char *
ngx_http_streams_slot(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    char  *p = conf;

    ngx_array_t     **streams;
    ngx_str_t        *value, *default_streams;
    ngx_uint_t        i, n, hash;
    ngx_hash_key_t   *stream;

    streams = (ngx_array_t **) (p + cmd->offset);

    if (*streams == (void *) -1) {
        return NGX_CONF_OK;
    }

    default_streams = cmd->post;

    if (*streams == NULL) {
        *streams = ngx_array_create(cf->temp_pool, 1, sizeof(ngx_hash_key_t));
        if (*streams == NULL) {
            return NGX_CONF_ERROR;
        }

        if (default_streams) {
            stream = ngx_array_push(*streams);
            if (stream == NULL) {
                return NGX_CONF_ERROR;
            }

            stream->key = *default_streams;
            stream->key_hash = ngx_hash_key(default_streams->data,
                                          default_streams->len);
            stream->value = (void *) 4;
        }
    }

    value = cf->args->elts;

    for (i = 1; i < cf->args->nelts; i++) {

        if (value[i].len == 1 && value[i].data[0] == '*') {
            *streams = (void *) -1;
            return NGX_CONF_OK;
        }

        hash = ngx_hash_strlow(value[i].data, value[i].data, value[i].len);
        value[i].data[value[i].len] = '\0';

        stream = (*streams)->elts;
        for (n = 0; n < (*streams)->nelts; n++) {

            if (ngx_strcmp(value[i].data, stream[n].key.data) == 0) {
                ngx_conf_log_error(NGX_LOG_WARN, cf, 0,
                                   "duplicate stream \"%V\"", &value[i]);
                goto next;
            }
        }

        stream = ngx_array_push(*streams);
        if (stream == NULL) {
            return NGX_CONF_ERROR;
        }

        stream->key = value[i];
        stream->key_hash = hash;
        stream->value = (void *) 4;

    next:

        continue;
    }

    return NGX_CONF_OK;
}


static char *
ngx_http_merge_streams(ngx_conf_t *cf, ngx_array_t **keys, ngx_hash_t *streams_hash,
    ngx_array_t **prev_keys, ngx_hash_t *prev_streams_hash,
    ngx_str_t *default_streams)
{
    ngx_hash_init_t  hash;

    if (*keys) {

        if (*keys == (void *) -1) {
            return NGX_CONF_OK;
        }

        hash.hash = streams_hash;
        hash.key = NULL;
        hash.max_size = 2048;
        hash.bucket_size = 64;
        hash.name = "test_streams_hash";
        hash.pool = cf->pool;
        hash.temp_pool = NULL;

        if (ngx_hash_init(&hash, (*keys)->elts, (*keys)->nelts) != NGX_OK) {
            return NGX_CONF_ERROR;
        }

        return NGX_CONF_OK;
    }

    if (prev_streams_hash->buckets == NULL) {

        if (*prev_keys == NULL) {

            if (ngx_http_set_default_streams(cf, prev_keys, default_streams)
                != NGX_OK)
            {
                return NGX_CONF_ERROR;
            }

        } else if (*prev_keys == (void *) -1) {
            *keys = *prev_keys;
            return NGX_CONF_OK;
        }

        hash.hash = prev_streams_hash;
        hash.key = NULL;
        hash.max_size = 2048;
        hash.bucket_size = 64;
        hash.name = "test_streams_hash";
        hash.pool = cf->pool;
        hash.temp_pool = NULL;

        if (ngx_hash_init(&hash, (*prev_keys)->elts, (*prev_keys)->nelts)
            != NGX_OK)
        {
            return NGX_CONF_ERROR;
        }
    }

    *streams_hash = *prev_streams_hash;

    return NGX_CONF_OK;

}


static ngx_int_t
ngx_http_set_default_streams(ngx_conf_t *cf, ngx_array_t **streams,
    ngx_str_t *default_streams)
{
    ngx_hash_key_t  *stream;

    *streams = ngx_array_create(cf->temp_pool, 1, sizeof(ngx_hash_key_t));
    if (*streams == NULL) {
        return NGX_ERROR;
    }

    while (default_streams->len) {

        stream = ngx_array_push(*streams);
        if (stream == NULL) {
            return NGX_ERROR;
        }

        stream->key = *default_streams;
        stream->key_hash = ngx_hash_key(default_streams->data,
                                      default_streams->len);
        stream->value = (void *) 4;

        default_streams++;
    }

    return NGX_OK;
}


static char *
ngx_http_time_offset(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ngx_http_live_m3u8_conf_t  *mlcf = conf;
    
    ngx_str_t        *value;
    u_char           *p;
    ngx_int_t         v;

    value = cf->args->elts;
    
    p = value[1].data;
    
    if (!(*p == '-' || *p == '+' || (*p >= '0' && *p <= '9'))) {
        return NGX_CONF_ERROR;
    }

    if (*p == '-' || *p == '+') {
        v = ngx_atoi(p + 1, value[1].len - 1);
    } else {
        v = ngx_atoi(p, value[1].len);
    }
    
    if (v == NGX_ERROR) {
        return NGX_CONF_ERROR;
    }
    
    if (*p == '-') {
        v = -v;
    }
    
    mlcf->time_offset = v;
    
    return NGX_CONF_OK;
}


static void *
ngx_http_live_m3u8_create_conf(ngx_conf_t *cf)
{
    ngx_http_live_m3u8_conf_t  *conf;

    conf = ngx_pcalloc(cf->pool, sizeof(ngx_http_live_m3u8_conf_t));
    if (conf == NULL) {
        return NULL;
    }

    /*
     * set by ngx_pcalloc():
     *
     *     conf->metas = { NULL };
     *     conf->metas_keys = NULL;
     *     conf->streams = { NULL };
     *     conf->streams_keys = NULL;
     *     conf->advertisements = NULL;
     *     conf->holo_stream = { 0, NULL };
     *     conf->logo_stream = { 0, NULL };
     *     conf->share_resp = { 0, NULL };
     *     conf->origin = { 0, NULL };
     *     conf->localhost = { 0, NULL };
     */

    conf->default_length = NGX_CONF_UNSET;
    conf->max_length = NGX_CONF_UNSET;
    conf->time_offset = NGX_CONF_UNSET;
    conf->segment_duration = NGX_CONF_UNSET;
    conf->advertising_titles = NGX_CONF_UNSET;
    conf->segments_per_playlist = NGX_CONF_UNSET_UINT;
    conf->dynamic_offset = NGX_CONF_UNSET;
    conf->live_mode = NGX_CONF_UNSET;
    conf->hls2mp4_logo = NGX_CONF_UNSET;
    return conf;
}


static char *
ngx_http_live_m3u8_merge_conf(ngx_conf_t *cf, void *parent, void *child)
{
    ngx_http_live_m3u8_conf_t *prev = parent;
    ngx_http_live_m3u8_conf_t *conf = child;

    ngx_conf_merge_value(conf->default_length, prev->default_length, 60);
    ngx_conf_merge_value(conf->time_offset, prev->time_offset, 0);

    if (ngx_http_merge_streams(cf, &conf->streams_keys, &conf->streams,
                             &prev->streams_keys, &prev->streams,
                             ngx_http_default_streams)
        != NGX_OK)
    {
        return NGX_CONF_ERROR;
    }

    if (ngx_http_merge_streams(cf, &conf->metas_keys, &conf->metas,
                             &prev->metas_keys, &prev->metas,
                             ngx_http_default_metas)
        != NGX_OK)
    {
        return NGX_CONF_ERROR;
    }

    ngx_conf_merge_value(conf->segment_duration, prev->segment_duration, 10);

    if (conf->advertisements == NULL) {
        conf->advertisements = prev->advertisements;
    }

    ngx_conf_merge_value(conf->advertising_titles, 
                               prev->advertising_titles, 0);

    ngx_conf_merge_str_value(conf->holo_stream, prev->holo_stream, "1400");
    ngx_conf_merge_str_value(conf->logo_stream, prev->logo_stream, "1400");
	 ngx_conf_merge_str_value(conf->local_addr, prev->local_addr, "127.0.0.1");
	ngx_conf_merge_str_value(conf->logo_resolution, prev->logo_resolution, "212x120");
    ngx_conf_merge_str_value(conf->share_resp, prev->share_resp, 
                             "127.0.0.1/response");
    ngx_conf_merge_str_value(conf->origin, prev->origin, "127.0.0.1");
    ngx_conf_merge_str_value(conf->localhost, prev->localhost, "127.0.0.1");
    ngx_conf_merge_str_value(conf->mergemp4_local_addr, prev->mergemp4_local_addr, "127.0.0.1");
    ngx_conf_merge_uint_value(conf->segments_per_playlist,
                         prev->segments_per_playlist, 3);
    ngx_conf_merge_value(conf->max_length, prev->max_length, 60);

    ngx_conf_merge_value(conf->dynamic_offset, prev->dynamic_offset, 0);
    ngx_conf_merge_value(conf->live_mode, prev->live_mode, 0);
    ngx_conf_merge_value(conf->hls2mp4_logo, prev->hls2mp4_logo, 0);
    return NGX_CONF_OK;
}
