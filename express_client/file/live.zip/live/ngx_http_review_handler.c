#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>

static ngx_int_t zip_review_files(ngx_http_request_t *r, ngx_buf_t* b, ngx_uint_t uuid, ngx_str_t resp_url, int is_meta, time_t start, time_t len);
static void execute_shell_scripts(ngx_http_request_t *r, const char* script_path, ngx_uint_t uuid, ngx_str_t resp_url, const char* m3u8_file, ngx_str_t localserver, ngx_str_t base_dir);
static int fetch_sub_m3u8(ngx_http_request_t *r, time_t start, time_t len, ngx_str_t* stream, char* sub_m3u8);

ngx_int_t 
ngx_http_review_handler(ngx_http_request_t *r)
{
    u_char                    *last;
    time_t                     now, start, len;
    size_t                     root;
    ngx_int_t                  rc;
    ngx_uint_t                 level;
    ngx_str_t                  path, stream, value;
    ngx_log_t                 *log;
    ngx_buf_t                 *b;
    ngx_chain_t                out;
    ngx_open_file_info_t       of;
    ngx_http_core_loc_conf_t  *clcf;
    ngx_http_live_m3u8_conf_t *hlcf;
	
	int is_meta;
	int         is_zip;
	ngx_uint_t  uuid;
	ngx_str_t   resp_url;
	
	is_meta = 0;
	is_zip = 0;
	uuid = 0;
	resp_url.data = 0;
	resp_url.len = 0;
	
    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

    if (r->args.len == 0) 
	{
        if (hlcf->live_mode) 
		{
            return NGX_DECLINED;
        }
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "starttime", 9, &value) != NGX_OK) {
        if (hlcf->live_mode) {
            return NGX_DECLINED;
        }
        return NGX_HTTP_BAD_REQUEST;
    }
    
    now = ngx_time();
    start = ngx_http_live_m3u8_timestamp(&value, hlcf->time_offset);

    if (start == NGX_ERROR) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (start >= now || start < NGX_LIVE_MEU8_MAX_TIME) {
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "length", 6, &value) == NGX_OK) {
        len = ngx_atotm(value.data, value.len);
    
        if (len == NGX_ERROR || len == 0) {
            len = hlcf->default_length;
        }
    } else {
        len = hlcf->default_length;
    }

    /*if (start + len > now) {
        len = now - start;
    }*/

	//由于现在需要将m3u8落为文件，因此回看这里需要对于时间进行控制，起始时间+回看时间 不能大于当前时间。
	if (start + len > now) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (len > hlcf->max_length) {
        len = hlcf->max_length;
    }

	if (ngx_http_arg(r, (u_char *) "zip", 3, &value) == NGX_OK) {
		is_zip = ngx_atoi(value.data, value.len);
		is_zip = is_zip == 1 ? 1 : 0;
	}

	if (ngx_http_arg(r, (u_char *) "uuid", 4, &value) == NGX_OK) {
		uuid = ngx_atoi(value.data, value.len);
	}

	if (ngx_http_arg(r, (u_char *) "response_address", 16, &value) == NGX_OK) {
		resp_url = value;
	}

	if (is_zip) {
		if (uuid == 0 || ! resp_url.data || ! resp_url.len) {
			return NGX_HTTP_BAD_REQUEST;
		}
	}
	
    r->root_tested = !r->error_page;

    if (ngx_http_test_stream_type(r, &hlcf->metas, &stream)) {

        b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
        if (b == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        goto meta;

    } else if (ngx_http_test_stream_type(r, &hlcf->streams, &stream)) {

        b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
        if (b == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        rc = ngx_http_live_m3u8_build_playlist(r, b, &stream, start, len, 0);

        if (rc == NGX_ERROR) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        goto done;

    } else {

        return NGX_DECLINED;
    }

meta:
    is_meta = 1;
    
    last = ngx_http_map_uri_to_path(r, &path, &root, 0);
    if (last == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    path.len = last - path.data;

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, log, 0, "http review filename: \"%V\"", &path);

    clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);

    ngx_memzero(&of, sizeof(ngx_open_file_info_t));

    of.read_ahead = clcf->read_ahead;
    of.directio = clcf->directio;
    of.valid = clcf->open_file_cache_valid;
    of.min_uses = clcf->open_file_cache_min_uses;
    of.errors = clcf->open_file_cache_errors;
    of.events = clcf->open_file_cache_events;

    if (ngx_http_set_disable_symlinks(r, clcf, &path, &of) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_open_cached_file(clcf->open_file_cache, &path, &of, r->pool)
        != NGX_OK)
    {
        switch (of.err) {

        case 0:
            return NGX_HTTP_INTERNAL_SERVER_ERROR;

        case NGX_ENOENT:
        case NGX_ENOTDIR:
        case NGX_ENAMETOOLONG:

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_NOT_FOUND;
            break;

        case NGX_EACCES:
#if (NGX_HAVE_OPENAT)
        case NGX_EMLINK:
        case NGX_ELOOP:
#endif

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_FORBIDDEN;
            break;

        default:

            level = NGX_LOG_CRIT;
            rc = NGX_HTTP_INTERNAL_SERVER_ERROR;
            break;
        }

        if (rc != NGX_HTTP_NOT_FOUND || clcf->log_not_found) {
            ngx_log_error(level, log, of.err, "%s \"%s\" failed", of.failed, path.data);
        }

        return rc;
    }

    if (!of.is_file) {

        if (ngx_close_file(of.fd) == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ALERT, log, ngx_errno, ngx_close_file_n " \"%s\" failed", path.data);
        }

        return NGX_DECLINED;
    }

    rc = ngx_http_live_m3u8_build_index(r, &of, &r->args, b);
    
    if (rc == NGX_ERROR){        
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

done:

	if (is_zip) {
		return zip_review_files(r, b, uuid, resp_url, is_meta, start, len);
	}

    log->action = "sending live_m3u8 to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);
    r->headers_out.last_modified_time = of.mtime;

    if (ngx_http_set_etag(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);
}

static ngx_int_t
create_dir_r(char *target_dir) {

	struct stat st;

	stat( target_dir ,&st);
	if (S_ISDIR(st.st_mode)) {
		printf("is a dir\n");
		//return 1;
	}	
	else {
		printf("is not a dir\n");
		remove(target_dir);
	}

	mkdir(target_dir, 0777);

	if (access(target_dir, 0) != 0) {
		return -1;	
	}

	return 1;
}	

static ngx_int_t
write_m3u8file(const char * m3u8_file , ngx_buf_t* ib) {

	FILE		*fp;
	u_char		*p_adr,*p_adr_end,*line_end_p , *m3u8_addr;

	
	fp = fopen(m3u8_file, "w+");
	if (!fp) {
		//ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);		
		return -1;
	}
/*
	p_adr =  ngx_strstr(ib->pos , ".m3u8");

	if((p_adr == NULL) || (p_adr +5 >(char *) ib->last)){
		fclose(fp);
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}
*/	

	if ( ib->pos < ib->last )
		p_adr = ib->pos;
	else
		return -1;

	while( p_adr < ib->last ) {

		line_end_p = ngx_strnstr( p_adr , "\r\n" , ib->last - p_adr) ;
		if( line_end_p == NULL)
			return -1;

		line_end_p +=2 ;

		m3u8_addr = (u_char *)ngx_strnstr(p_adr , ".m3u8" , line_end_p - p_adr  );
		if( m3u8_addr != NULL) {

			p_adr_end = m3u8_addr +5;
			
			if (fwrite(p_adr, 1, p_adr_end - p_adr, fp) != (size_t)(p_adr_end - p_adr)) { //ib->last
				fclose(fp);
				//ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
				return -1;
			}

			if (fwrite("\r\n", 1, 2 , fp) != 2) { //ib->last
				fclose(fp);
				//ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
				return -1;
			}
			
		}	
		else {	
			if (fwrite(p_adr, 1, line_end_p - p_adr, fp) != (size_t)(line_end_p - p_adr)) { //ib->last
				fclose(fp);
				//ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
				return -1;
			}
		}

		p_adr = line_end_p ;
	}
	
	fclose(fp);
	return 1;
}




static ngx_int_t 
zip_review_files(ngx_http_request_t *r, ngx_buf_t* ib, ngx_uint_t uuid, ngx_str_t resp_url, int is_meta, time_t start, time_t len) {
	static const char* zip_dir = "/data1/zipdir";
	static const char* script_path = "/usr/local/bin/pack2zip.py";
		
	char 		buffer[512];
	char 		m3u8_file[512];
	FILE* 		fp;
	ngx_int_t 	rc;
	ngx_buf_t* 	b;
	ngx_chain_t out;
	u_char* 	content;

	u_char     	*last, *p;
	size_t     	root;
    ngx_str_t  	base;
	//char*		p_adr = NULL;

	last = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (last == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

	for (p = last - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }

	base.len -= (last - p);

	if( create_dir_r("/data1") < 0) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "%s not exist", buffer);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;			
	}

	if( create_dir_r("/data1/zipdir") < 0) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "%s not exist", buffer);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;			
	}

	snprintf(buffer, sizeof(buffer), "%s/%llu", zip_dir, (unsigned long long)uuid);
	if( create_dir_r(buffer) < 0) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "%s not exist", buffer);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;			
	}
/*	
	mkdir(buffer, 0777);
	
	if (access(buffer, 0) != 0) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "%s not exist", buffer);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;	
	}
*/
	strncpy(m3u8_file, buffer, sizeof(m3u8_file)-1);
	strcat(m3u8_file, "/index.m3u8");
/*
	fp = fopen(m3u8_file, "w+");
	if (!fp) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "open %s failed", m3u8_file);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	p_adr =  ngx_strstr(ib->pos , ".m3u8");

	if((p_adr == NULL) || (p_adr +5 >(char *) ib->last)){
		fclose(fp);
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}
		
		
	if (fwrite(ib->pos, 1, ib->last - ib->pos, fp) != (size_t)(ib->last - ib->pos)) { //ib->last
		fclose(fp);
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	fclose(fp);
*/	
	if ( write_m3u8file(m3u8_file , ib) < 0 ) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "write %s failed", m3u8_file);		
		return NGX_HTTP_INTERNAL_SERVER_ERROR;	
	}
	
	if (is_meta) {
		fp = fopen(m3u8_file, "r");
		if (!fp) {
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "open %s failed", m3u8_file);
			return NGX_HTTP_INTERNAL_SERVER_ERROR;
		}
		
		char line[300];
		char sub_m3u8[512];
		char vb[32];
		int vb_i;
		ngx_str_t stream_str;
		
		while(fgets(line, sizeof(line), fp)) {
			line[sizeof(line)-1] = '\0';
			if( strstr(line ,".m3u8") )  {
				char sub_line[300];
				//sub_dir2[0] = '\0'; 

		        sprintf(sub_line, "%s", line);				
				while(strstr(line, "/"))
			    {
			    	int ret = 0;
			        ret = sscanf(line, "%*[^/]/%s",  sub_line);
					if( ret == 1 ) {
				        sprintf(line, "%s", sub_line);
					}	
					else
						break;
			    };

				
				if (sscanf(sub_line, "%d.m3u8?%*s", &vb_i) == 1) {
					snprintf(vb,sizeof(vb),"%d",vb_i);
					snprintf(sub_m3u8, sizeof(sub_m3u8), "%s/%d.m3u8", buffer, vb_i);
					
					stream_str.data = (u_char*)vb;
					stream_str.len = strlen(vb);
					
					fetch_sub_m3u8(r, start, len, &stream_str, sub_m3u8);
				}
			}	
		}
		
		fclose(fp);
	}
	
	r->connection->log->action = "sending ansync resp content 0 to client";

	content = ngx_pcalloc(r->pool, 1);
	if (content == NULL) {
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	*content = '0';

	b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
	if (b == NULL) {
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}
	
	out.buf = b;
    out.next = NULL;
 
    b->pos = content;
    b->last = content + 1;
    b->memory = 1;   
    b->last_buf = 1; 
    b->last_in_chain = 1;
 
    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = 1;
 
    rc = ngx_http_send_header(r);

	if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

	rc = ngx_http_output_filter(r, &out);

	execute_shell_scripts(r, script_path, uuid, resp_url, m3u8_file, r->headers_in.host->value, base);
	
	return rc;

}

static void execute_shell_scripts(ngx_http_request_t *r, const char* script_path, ngx_uint_t uuid, ngx_str_t resp_url, const char* m3u8_file, ngx_str_t localserver, ngx_str_t base_dir) {
	char cmd[1000] = {0};

	char notify_url[300] = {0};
	char local_ipport[128] = {0};
	char base_directory[300] = { 0 };
	
	ngx_snprintf((u_char*)notify_url, sizeof(notify_url), "%V", &resp_url);
	ngx_snprintf((u_char*)local_ipport, sizeof(local_ipport), "%V", &localserver);
	ngx_snprintf((u_char*)base_directory, sizeof(base_directory), "%V", &base_dir);

	snprintf(cmd, sizeof(cmd), "nohup %s %llu \"%s\" \"%s\" \"%s\" \"%s\" >/dev/null 2>&1 &", 
		script_path, (unsigned long long)uuid, notify_url, m3u8_file, local_ipport, base_directory);

	ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, 
		"execute command: %s", cmd);
	
	system(cmd);
}

static int fetch_sub_m3u8(ngx_http_request_t *r, time_t start, time_t len, ngx_str_t* stream, char* sub_m3u8) {
    ngx_int_t                  rc;
    ngx_log_t                 *log;
    ngx_buf_t                 *b;
		
	FILE* fp;
	
    log = r->connection->log;

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
    	return -1;
    }

    rc = ngx_http_live_m3u8_build_playlist(r, b, stream, start, len, 0);

    if (rc == NGX_ERROR) {
    	return -2;
    }
 	
 	fp = fopen(sub_m3u8, "w+");
	if (!fp) {
		ngx_log_error(NGX_LOG_ERR, log, 0, "open %s failed", sub_m3u8);
		return -3;
	}

	if (fwrite(b->pos, 1, b->last - b->pos, fp) != (size_t)(b->last - b->pos)) {
		fclose(fp);
		ngx_log_error(NGX_LOG_ERR, log, 0, "write %s failed", sub_m3u8);
		return -4;
	}

	fclose(fp);
 	
   return 0;
}
