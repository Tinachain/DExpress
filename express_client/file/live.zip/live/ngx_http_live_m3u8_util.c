#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>

static u_char *
strrstr (u_char *string,  u_char *str)
{
    u_char     *index;
    u_char     *ret;
    ngx_int_t   i;

    i = 0;
    ret = NULL;
    index = NULL;

    do {
        index = (u_char *) ngx_strstr((string + i++), str);
        
        if (index != NULL) 
        {
            ret = index;
        }

    } while (index != NULL);

	printf("str = %s",ret);
    
    return ret;
}

static ngx_int_t 
ngx_http_live_m3u8_time(ngx_str_t *date, ngx_str_t *time, ngx_int_t offset)
{
    u_char          *p;
    struct tm        tm;
    time_t           now, st;

    now = ngx_time();
    ngx_libc_localtime(now, &tm);

    p = date->data;

    for (; p != date->data + date->len; p++) 
    {
        if (*p < '0' || *p > '9') 
        {
            return -1;
        }
    }

    p = date->data;

    /* year */
    tm.tm_year = *p++ - '0';
    tm.tm_year = tm.tm_year * 10 + *p++ - '0';
    tm.tm_year = tm.tm_year * 10 + *p++ - '0';
    tm.tm_year = tm.tm_year * 10 + *p++ - '0';
    tm.tm_year -= 1900;

    /* month */
    tm.tm_mon = *p++ - '0';
    tm.tm_mon = tm.tm_mon * 10 + *p++ - '0';
    tm.tm_mon -= 1;

    /* day */
    tm.tm_mday  = *p++ - '0';
    tm.tm_mday  = tm.tm_mday * 10 + *p++ - '0';

    p = time->data;

    for (; p != time->data + time->len; p++) {
        if (*p < '0' || *p > '9') {
            return -1;
        }
    }

    p = time->data;

    /* hour */
    tm.tm_hour = *p++ - '0';
    tm.tm_hour = tm.tm_hour * 10 + *p++ - '0';

    /* minute */
    tm.tm_min = *p++ - '0';
    tm.tm_min = tm.tm_min * 10 + *p++ - '0';

    /* second */
    tm.tm_sec = *p++ - '0';
    tm.tm_sec = tm.tm_sec * 10 + *p++ - '0';

    st = mktime(&tm);
    if (st == -1) {
        return st;
    }

    st += offset;

    return st;
}

ngx_int_t
ngx_http_live_m3u8_timestamp(ngx_str_t *src, ngx_int_t offset)
{
    u_char          *p;
    ngx_str_t        date, time;
    
    /* 20150710T164717 */
    p = src->data;
    
    date.data = p;
    date.len = 8;
    
    for (; p != date.data + 8; p++) {
        if (*p < '0' || *p > '9') {
            return NGX_ERROR;
        }
    }
    
    if (*p++ != 'T') {
        return NGX_ERROR;
    }
    
    time.data = p;
    time.len = 6;
    
    for (; p != time.data + 6; p++) {
        if (*p < '0' || *p > '9') {
            return NGX_ERROR;
        }
    }

    return ngx_http_live_m3u8_time(&date, &time, offset);
}

ngx_int_t
save_m3u8_file(ngx_http_request_t *r, ngx_str_t *path, time_t time, ngx_str_t *stream, ngx_int_t duration, u_char *buf, int len) 
{
    ngx_str_t                  file;
    u_char                    *last;
    struct tm                  tm;
    FILE *fp = NULL;

    file.data = ngx_pcalloc(r->pool, path->len + 32); 
    if (file.data == NULL) {
        return NGX_ERROR;        
    }

    //计算起始行数;
    ngx_localtime(time, &tm);   

    //将起始时间转换为文件名称
    last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/%02d%02d%02d_%d.m3u8", path, 
                                                                    stream, 
                                                                    tm.tm_year, 
                                                                    tm.tm_mon, 
                                                                    tm.tm_mday,
                                                                    tm.tm_hour,
                                                                    tm.tm_min,
                                                                    tm.tm_sec,
                                                                    duration);
    file.len = last - file.data;
    *last = 0;

	fp = fopen((char*)file.data, "w+");
	if (!fp) 
    {
		return -1;
	}
	fwrite(buf, len, 1, fp);
	fclose(fp);
	return 0;
}

//得到m3u8的文件名称
ngx_int_t
ngx_http_check_m3u8_file(ngx_http_request_t *r, 
                        ngx_str_t *path, 
                        time_t time, 
                        ngx_str_t *stream, 
                        ngx_int_t duration, 
                        u_char *buf)
{
    ngx_str_t                  file;
    u_char                    *last;
    struct tm                  tm;
    ngx_fd_t                   fd = -1;
    ngx_int_t                  size;
    ngx_int_t                  offset = 0;

    file.data = ngx_pcalloc(r->pool, path->len + 32); 
    if (file.data == NULL) {
        return NGX_ERROR;        
    }

    //计算起始行数;
    ngx_localtime(time, &tm);   

    //将起始时间转换为文件名称
    last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/%02d%02d%02d_%d.m3u8", path, 
                                                                    stream, 
                                                                    tm.tm_year, 
                                                                    tm.tm_mon, 
                                                                    tm.tm_mday,
                                                                    tm.tm_hour,
                                                                    tm.tm_min,
                                                                    tm.tm_sec,
                                                                    duration);
    file.len = last - file.data;
    *last = 0;

    fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
    if(NGX_INVALID_FILE == fd)
    {
        return NGX_ERROR;
    }

    //文件存在，直接获取此文件信息;
    if (-1 == lseek(fd, 0, SEEK_SET)) 
    {
        ngx_close_file(fd);
        return NGX_ERROR;
    }

    offset = 0;
    while(1)
    {
        size = read(fd, buf + offset, 32 * 1024);
        if (-1 == size) 
        {
            if(0 == offset)
            {
                ngx_close_file(fd);
                return NGX_ERROR; 
            }
            ngx_close_file(fd);
            return offset;
        }
        
        if(size < 32 * 1024)
        {
            ngx_close_file(fd);
            return offset + size;
        }
        offset += 32 * 1024;
    }
}

ngx_int_t
ngx_http_live_m3u8_get_index(   ngx_http_request_t *r, 
                                ngx_str_t *path, 
                                time_t time, 
                                ngx_str_t *stream, 
                                ngx_int_t duration, 
                                ngx_int_t type, 
                                u_char *buf)
{
    ngx_str_t                  file;
    u_char                    *last;
    struct tm                  tm;
    ngx_fd_t                   fd;
    ngx_int_t                  n, start;
    ngx_int_t                  offset = 0;

    //判断是否是回看
    if(NGX_REVIEW == type)
    {
        //判断回看的m3u8文件是否存在;
        ngx_int_t ret = ngx_http_check_m3u8_file(r, path, time, stream, duration, buf);
        if(ret > NGX_OK)
        {
            return ret;
        }
    }
   
    file.data = ngx_pcalloc(r->pool, path->len + 32); 
    if (file.data == NULL) {
        return NGX_ERROR;        
    }

    //计算起始行数;
    ngx_localtime(time, &tm);   
    start = tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec;

    //判断是否是T000000
    if (0 == start){

        /* last day */
        ngx_localtime(time - 86400, &tm);
        last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, stream, tm.tm_year, tm.tm_mon, tm.tm_mday);
        file.len = last - file.data;
        *last = 0;

        fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
        if (fd == NGX_INVALID_FILE) {

            ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
            goto currday;
        }

        if (lseek(fd, (86400 * NGX_LIVE_M3U8_INDEX_LINE_SIZE  - NGX_LIVE_M3U8_INDEX_LINE_SIZE), SEEK_SET) == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "lseek() \"%s\" failed", file.data);
            goto currday;
        }

        n = read(fd, buf, NGX_LIVE_M3U8_INDEX_LINE_SIZE);
        if (n == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
            goto currday;
        }
        offset += n;

currday:
        if(-1 != fd){
            if (ngx_close_file(fd) == NGX_FILE_ERROR) {

                ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
            }
        }
        fd = -1;

        //得到当前天的事件;
        ngx_localtime(time, &tm);   
        last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, stream, tm.tm_year, tm.tm_mon, tm.tm_mday);
        file.len = last - file.data;
        *last = 0;

        fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
        if (fd == NGX_INVALID_FILE) {

            ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
            return NGX_ERROR;
        }

        if (lseek(fd, 0, SEEK_SET) == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "lseek() \"%s\" failed", file.data);
            goto failed;
        }

        n = read(fd, buf + offset, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE - offset);
        if (n == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
            goto failed;
        }

        if (n + offset < duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
            /* next day */

            if (ngx_close_file(fd) == NGX_FILE_ERROR) {

                ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
            }

            fd = -1;
            ngx_localtime(time + 86400, &tm);
            last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, stream, tm.tm_year, tm.tm_mon, tm.tm_mday);
            file.len = last - file.data;
            *last = 0;

            fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
            if (fd == NGX_INVALID_FILE) {

                ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
                goto failed;
            }

            n = read(fd, buf + n, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE - n - NGX_LIVE_M3U8_INDEX_LINE_SIZE);
            if (n == -1) {

                ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
                goto failed;
            }
        }

        if (ngx_close_file(fd) == NGX_FILE_ERROR) {

            ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
        }

        //保存这个m3u8文件
        //save_m3u8_file(r, path, time, stream, buf, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);

        //测试使用保存成文件;
        //write_tempfile("/var/www/lighttpd/otv/test/review/channel228/233.m3u8", buf, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    }
    else if(start > 0)
    {
        last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, stream, tm.tm_year, tm.tm_mon, tm.tm_mday);
        file.len = last - file.data;
        *last = 0;

        fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
        if (fd == NGX_INVALID_FILE) {

            ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
            return NGX_ERROR;
        }

        if (lseek(fd, (start - 1) * NGX_LIVE_M3U8_INDEX_LINE_SIZE, SEEK_SET) == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "lseek() \"%s\" failed", file.data);
            goto failed;
        }

        n = read(fd, buf, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
        if (n == -1) {

            ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
            goto failed;
        }

        if (n < duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
            /* next day */

            if (ngx_close_file(fd) == NGX_FILE_ERROR) {

                ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
            }

            fd = -1;

            ngx_localtime(time + 86400, &tm);

            last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, stream, tm.tm_year, tm.tm_mon, tm.tm_mday);

            file.len = last - file.data;
            *last = 0;

            fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
            if (fd == NGX_INVALID_FILE) {

                ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
                goto failed;
            }

            n = read(fd, buf + n, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE - n);
            if (n == -1) {

                ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
                goto failed;
            }
        }

        if (ngx_close_file(fd) == NGX_FILE_ERROR) {

            ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
        }
    }

    //保存这个m3u8文件
    //save_m3u8_file(r, path, time, stream, buf, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);

    return NGX_OK;

failed:
    if (fd != -1) {
        if (ngx_close_file(fd) == NGX_FILE_ERROR) {

            ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
        }
    }

    return NGX_ERROR;
}

ngx_int_t
ngx_http_live_m3u8_get_index_for_get_pic(ngx_http_request_t *r, ngx_str_t *path, time_t time, ngx_str_t *stream, u_char *buf)
{
    ngx_str_t                  file;
    u_char                    *last;
    struct tm                  tm;
    ngx_fd_t                   fd;
    ngx_int_t                  n = 0, start;

	file.data = ngx_pcalloc(r->pool, path->len + 32); 
	if (file.data == NULL) {

	    return NGX_ERROR;        
	}

    if (time == 0) {

		tm.tm_hour = 0;
		tm.tm_min = 0;
		tm.tm_sec = 0;
		/* exzample: /var/www/lighttpd/channel01/700.m3u8 */
		last = ngx_sprintf(file.data, "%V%V.m3u8", path, stream);
	
    } else{

		ngx_localtime(time, &tm);	
		/* exzample: /var/www/lighttpd/channel01/700/20170624/replay.txt */
		last = ngx_sprintf(file.data, "%V%V/%04d%02d%02d/replay.txt", path, 
					       stream, tm.tm_year, tm.tm_mon, tm.tm_mday);
	}

	file.len = last - file.data;
	*last = 0;

    start = tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec;
	fd = ngx_open_file(file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
	
    if (fd == NGX_INVALID_FILE) {

        ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " \"%s\" failed", file.data);
        return NGX_ERROR;
    }

	if (start == 0) {

        u_char *temp_data = ngx_pcalloc(r->pool, 2 * NGX_LIVE_M3U8_INDEX_LINE_SIZE + 1);
        if (temp_data == NULL) {

			return NGX_ERROR;
		}

		u_char *temp_str = ngx_pcalloc(r->pool, NGX_LIVE_M3U8_INDEX_LINE_SIZE); 
		if (temp_str == NULL) {

			return NGX_ERROR;
		}

		if (lseek(fd, - (2 * NGX_LIVE_M3U8_INDEX_LINE_SIZE) , SEEK_END) == -1) 
        {
			ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "lseek() \"%s\" failed", file.data);
			goto failed;
		
        } else {
			
            n = read(fd, temp_data, 2 * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
            /* where is the return check */
		    
			//for example "700/"
			ngx_sprintf(temp_str, "%V/",stream);
			//����bitrate ��700  ����"700/" �� data_temp ���һ�γ��ֵ�λ�á� 
			u_char *last_start_word = strrstr (temp_data, temp_str);
		    u_char *last_end_word = strrstr (temp_data, (u_char *) ".ts");
		    
            int len = last_end_word -  last_start_word;
			//NGX_LIVE_M3U8_INDEX_LINE_SIZE should subtract the length of ".ts," 
			if (len < 0 || len > NGX_LIVE_M3U8_INDEX_LINE_SIZE - 4) {

                ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\"read ts from m3u8 failed len = %d", file.data,len);
                goto failed;
			}

			// len should add the length of ".ts"
			strncpy((char *) buf, (const char *)last_start_word, len + 3);
			strncat((char *) buf, "," , 1);
		}

	} else {
		
        ngx_int_t  i;
		
        for (i = 1; i < start; i++) {
			
            if (lseek(fd, (start - i ) * NGX_LIVE_M3U8_INDEX_LINE_SIZE, SEEK_SET) == -1) 
            {
				ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "lseek() \"%s\" failed", file.data);
				goto failed;

            } else {
				n = read(fd, buf, NGX_LIVE_M3U8_INDEX_LINE_SIZE);
                /* where is the return check */

				if (*buf == 0x20) {
					continue;
				
                } else {
					
                    if (i > 60) {
						ngx_log_error(NGX_LOG_CRIT, r->connection->log, 
                                      ngx_errno,
									  "\nread() \"%s\"success,but the ts is "
                                      "60s,it is too big, or the start time "
                                      "is big than latest ts 60s,shoud "
                                      "return error\n", 
                                      file.data);
						goto failed;

					}

		            break;
				}
			}
		}
	}
	
    if (n == -1) {

        ngx_log_error(NGX_LOG_CRIT, r->connection->log, ngx_errno, "read() \"%s\" failed", file.data);
        goto failed;
    }

    if (ngx_close_file(fd) == NGX_FILE_ERROR) {

        ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
    }

    return NGX_OK;

failed:
    if (fd != -1) {
        if (ngx_close_file(fd) == NGX_FILE_ERROR) {

            ngx_log_error(NGX_LOG_ALERT, r->connection->log, ngx_errno, ngx_close_file_n " replay.txt failed");
        }
    }

    return NGX_ERROR;
}

static void *
ngx_http_test_stream_type_internal(ngx_http_request_t *r, ngx_hash_t *streams_hash, ngx_str_t *stream)
{
    u_char      c, *lowcase, *p;
    ngx_uint_t  i, hash;

    if (streams_hash->size == 0) {
        return (void *) 4;
    }

    lowcase = ngx_pnalloc(r->pool, stream->len);
    if (lowcase == NULL) {
        return NULL;
    }

    hash = 0;
    p = stream->data;

    for (i = 0; i < stream->len; i++) {
        c = ngx_tolower(p[i]);
        hash = ngx_hash(hash, c);
        lowcase[i] = c;
    }

    return ngx_hash_find(streams_hash, hash, lowcase, stream->len);
}

void *
ngx_http_test_stream_type(ngx_http_request_t *r, ngx_hash_t *streams_hash, ngx_str_t *stream)
{
    u_char     *p;

    if (streams_hash->size == 0) 
    {
        return (void *) 4;
    }

    for (p = r->exten.data - 1; p != r->uri.data - 1; p--) 
    {
        if (*p == '/') {
            break;
        }
    }

    p++;

    stream->data = p;
    stream->len = r->exten.data - 1 - p;

    return ngx_http_test_stream_type_internal(r, streams_hash, stream);
}

static ngx_str_t
ngx_read_line(u_char *buffer, u_char **pos, const size_t len)
{
	u_char      *begin = buffer;
	u_char      *p = begin;
	u_char      *end = p + len;
	ngx_str_t    line;

	while (p < end) 
    {
        if ((*p == '\r') || (*p == '\n') || (*p == '\0')) {
			break;
		}
		p++;
	}

	/* copy line excluding \n or \0 */
	line.data = begin;
	line.len = p - begin;

    while ((*p == '\r') || (*p == '\n') || (*p == '\0')) 
    {

        if (*p == '\0') 
        {            
            *pos = end;
            break;
        } 
        else
        {
            /* next pass start after \r and \n */
            p++;
            *pos = p;
        }   
    }

    /* without '\r' '\n' '\0' */
    if (p == end) 
    {
        *pos = p;
    }

    return line;
}

ngx_int_t
ngx_http_live_m3u8_build_index(ngx_http_request_t *r, ngx_open_file_info_t *of, ngx_str_t *add_args, ngx_buf_t *b)
{
    u_char                    *buf, *p, *last, *pos, *start, *end;
    ngx_array_t                stream;
    ngx_str_t                  line;
    ngx_uint_t                 i, len;
    ngx_http_live_m3u8_conf_t *conf;

    struct stream_info_s {
        u_char     *pos;
        u_char     *last;
        ngx_int_t   args;
        ngx_str_t   stream;
    } streams[4], *s;

    buf = ngx_palloc(r->pool, of->size);
    if (buf == NULL) 
    {
        return NGX_ERROR;
    }

    if (read(of->fd, buf, of->size) != of->size) 
    {
        return NGX_ERROR;
    }

    pos = buf;
    last = buf + of->size;
    start = NULL;
    s = NULL;

    stream.nelts = 0;
    stream.elts = &streams;
    stream.size = sizeof(struct stream_info_s);
    stream.nalloc = 4;
    stream.pool = r->pool;

    for ( ;; ) 
    {

        line = ngx_read_line(pos, &pos, last - pos);
        if (line.data == NULL) {
            break;
        }

        if (ngx_strncmp(line.data, (u_char *) "#EXT-X-STREAM-INF", sizeof("#EXT-X-STREAM-INF") - 1) == 0) 
        {
            start = line.data;

        } else if (!(*line.data == '#' || *line.data == '\r' 
                   || *line.data == '\n' || *line.data == '\0')) 
        {
            if (start == NULL) {
                continue;
            }

            s = ngx_array_push(&stream);
            if (s == NULL) {
                return NGX_ERROR;
            }

            end = ngx_strlchr(line.data, line.data + line.len, '?');
            if (end == NULL) {
                end = line.data + line.len;
                s->args = 0;

            } else {
                s->args = 1;
            }

            for (p = end - 5 - 1; p != line.data - 1; p--) 
            {
                if (*p == '/') 
                {
                    break;
                }
            }

            p++;

            s->pos = start;
            s->last = line.data + line.len;
            s->stream.data = p;
            s->stream.len = (end - p) - 5;
        }

        if (pos >= last) {
            break;
        }
    }

    if (stream.nelts == 0) {
        return NGX_ERROR;
    }

    len = of->size + stream.nelts * (add_args->len + 3);
    pos = ngx_palloc(r->pool, len);
    if (pos == NULL) {
        return NGX_ERROR;
    }
 
    s = stream.elts;

    p = ngx_copy(pos, buf, s[0].pos - buf);

    conf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);

    for (i = 0; i < stream.nelts; i++) {

        if (ngx_http_test_stream_type_internal(r, &conf->streams, &s[i].stream) == NULL)
        {
            continue;
        }

        p = ngx_copy(p, s[i].pos, s[i].last - s[i].pos);
        if (s[i].args) {
            *p++ = '&';
        } else {
            *p++ = '?';
        }
        p = ngx_copy(p, add_args->data, add_args->len);
        *p++ = '\r';
        *p++ = '\n';
    }

    b->pos = pos;
    b->last = p;
    b->memory = 1;
    b->start = pos;
    b->end = pos + len;
    b->last_buf = 1;
    b->last_in_chain = 1;
    
    return NGX_OK;
}

//创建回看使用的m3u8信息;
ngx_int_t
ngx_http_live_m3u8_build_playlist(ngx_http_request_t *r, ngx_buf_t *b, ngx_str_t *stream, time_t start, time_t duration, ngx_int_t share)
{
    ngx_uint_t                 n, len, size, m;
    u_char                    *last, *buf, *p, *q, *path, *data;
    u_char                    *extid;
    //ngx_file_info_t            fi;
    ngx_int_t                  rc;
    ngx_uint_t                 i;
    ngx_http_live_m3u8_conf_t *conf;
    ngx_keyval_t              *src;
    size_t                     root;
    ngx_str_t                  base, value, rsa;

    n = 0;
    rsa.len = 0;

    conf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    data = ngx_palloc(r->pool, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (data == NULL) {
        return NGX_ERROR;
    }

    last = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (last == NULL) {
        return NGX_ERROR;
    }

    for (p = last - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }

    base.len -= (last - p);

    //判断回看文件是否存在，回看文件名称是按照starttime来生成的，如果文件存在，则返回的是这个文件的大小。
    rc = ngx_http_live_m3u8_get_index(r, &base, start, stream, duration, NGX_REVIEW, data);
    if (rc == NGX_ERROR) 
    {
        return NGX_ERROR;
    }

    if(rc > NGX_OK)
    {
        len = rc;
        b->pos = data;
        b->last = data + len;
        b->memory = 1;
        b->start = data;
        b->end = data + len;
        b->last_buf = 1;
        b->last_in_chain = 1;
        return NGX_OK;
    }

    //计算生成的m3u8文件的长度;
    len = 9;    /* #EXTM3U\r\n */
    len += 18;  /* #EXT-X-VERSION:3\r\n */
    len += 26;  /* #EXT-X-TARGETDURATION:11\r\n */
    len += 25;  /* #EXT-X-MEDIA-SEQUENCE:0\r\n */

    //如果存在广告，需要计算广告的长度;
    if (share && conf->advertisements && conf->advertisements->nelts) 
    {
        len += 24; /* #EXT-X-DISCONTINUITY\r\n */

        src = conf->advertisements->elts;
        for (i = 0; i < conf->advertisements->nelts; i++) {
            len += (14 + src[i].value.len); /* #EXTINF:%d,\r\n */
            len += (2 + src[i].key.len);    /* "%V\r\n" */
        }
    }

    //计算m3u8的文件长度;
    m = 0;
    for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) 
    {
        if (*p == 0x20) 
        {
            continue;
        }

        //判断格式是否符合要求;
        extid = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, '#');       
        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if(NULL == extid && NULL == last)
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
            return NGX_ERROR; 
        }

        if(last != NULL)
        {
            last++;
            n = ngx_atoi(last, 2);
            m = ngx_max(m, n);

            /* 600/20150725/143778565.ts\r\n */
            len +=  13; /* #EXTINF:10,\r\n */    
            len += 265; /* #EXTID: \r\n*/ 
            len += (last - p + 2); 
        }       
    }
    len += 16; /* #EXT-X-ENDLIST\r\n */

    //申请出需要设置m3u8大小的文件长度;
    buf = ngx_palloc(r->pool, len);
    if (buf == NULL) 
    {
        return NGX_ERROR;
    }
    last = buf;

    //设置m3u8头部信息;
    last = ngx_copy(last, "#EXTM3U\r\n", 9);
    last = ngx_copy(last, "#EXT-X-VERSION:3\r\n", 18);
    last = ngx_sprintf(last, "#EXT-X-TARGETDURATION:%d\r\n", m);
    last = ngx_copy(last, "#EXT-X-MEDIA-SEQUENCE:0\r\n", 25);

    //头部广告;
    if (conf->advertising_titles) 
    {
        if (share == 1 && conf->advertisements && conf->advertisements->nelts) 
        {              
            src = conf->advertisements->elts;
            for (i = 0; i < conf->advertisements->nelts; i++) 
            {
                
                last = ngx_sprintf(last, "#EXTINF:%d,\r\n", ngx_atoi(src[i].value.data, src[i].value.len));
                last = ngx_sprintf(last, "%V\r\n", &src[i].key);
            }
            last = ngx_sprintf(last, "#EXT-X-DISCONTINUITY\r\n");
        }
    }

    size = base.len + 1 + stream->len + 8 + 1 + 12 + 1;
    path = ngx_pnalloc(r->pool, size);
    if (path == NULL) {
        return NGX_ERROR;
    }

    //循环判断添加内容;
    for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) 
    {
        if (*p == 0x20) {
            continue;
        }

        extid = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, '#');
        q = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (NULL == q && NULL == extid) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
            return NGX_ERROR;        
        }
        

        if(extid != NULL)
        {
            rsa.data = p;
            rsa.len = 265;
        }
        else if(q != NULL)
        {
            n = ngx_atoi(q + 1, 2);
            value.data = p;
            value.len = q - p;
        }
        
        if(q != NULL && rsa.len > 0)
        {
            q = ngx_copy(path, base.data, base.len);
            q = ngx_sprintf(q, "%V", &value);
            *q = 0;

            //检测写入m3u8中的文件是否存在;
            /*rc = ngx_file_info(path, &fi);
            if (rc == NGX_FILE_ERROR) {

                ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, path);
                continue;
            }*/

            last = ngx_sprintf(last, "#EXTINF:%d,\r\n", n);
            last = ngx_sprintf(last, "%V\r\n%V\r\n", &rsa, &value);

            rsa.len = 0;
        }
    }

    //添加广告;
    if (conf->advertising_titles == 0) 
    {
        if (share == 1 && conf->advertisements && conf->advertisements->nelts) 
        {
            last = ngx_sprintf(last, "#EXT-X-DISCONTINUITY\r\n");
            src = conf->advertisements->elts;
            for (i = 0; i < conf->advertisements->nelts; i++) 
            {
                last = ngx_sprintf(last, "#EXTINF:%d,\r\n", ngx_atoi(src[i].value.data, src[i].value.len));
                last = ngx_sprintf(last, "%V\r\n", &src[i].key);
            }
        }
    }

    //输入结尾;
    last = ngx_copy(last, "#EXT-X-ENDLIST\r\n", 16);

    //保存这个m3u8文件
    save_m3u8_file(r, &base, start, stream, duration, buf, len);

    b->pos = buf;
    b->last = last;
    b->memory = 1;
    b->start = buf;
    b->end = buf + len;
    b->last_buf = 1;
    b->last_in_chain = 1;

    return NGX_OK;
}

//创建直播使用的m3u8信息;
ngx_int_t
ngx_http_live_m3u8_build_live_playlist(ngx_http_request_t *r, ngx_buf_t *b, ngx_str_t *stream, time_t start, time_t duration, ngx_uint_t sequence)
{
    ngx_uint_t                 n, len, size, m;
    u_char                    *last, *buf, *p, *q, *path, *data;
    u_char                    *extid;
    //ngx_file_info_t            fi;
    ngx_int_t                  rc;
    ngx_uint_t                 i;
    size_t                     root;
    ngx_str_t                  base, value, rsa;

    n = 0;
    rsa.len = 0;

    data = ngx_palloc(r->pool, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (data == NULL) 
    {
        return NGX_ERROR;
    }

    last = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (last == NULL) 
    {
        return NGX_ERROR;
    }

    for (p = last - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }

    base.len -= (last - p);

    rc = ngx_http_live_m3u8_get_index(r, &base, start, stream, duration, NGX_LIVE, data);
    if (rc == NGX_ERROR) {
        return NGX_ERROR;
    }

    len = 9;    /* #EXTM3U\r\n */
    len += 18;  /* #EXT-X-VERSION:3\r\n */
    len += 26;  /* #EXT-X-TARGETDURATION:11\r\n */
    len += 45;  /* #EXT-X-MEDIA-SEQUENCE:0\r\n */

    m = 0;
    for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) 
    {
        if (*p == 0x20) 
        {
            continue;
        }

        extid = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, '#');
        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (NULL == last && NULL == extid)
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
            return NGX_ERROR;        
        }

        if(last != NULL)
        {
            last++;
            n = ngx_atoi(last, 2);
            m = ngx_max(m, n);

            /* 600/20150725/143778565.ts\r\n */
            len +=  13; /* #EXTINF:10,\r\n */    
            len += 265; /* #EXTID:  \r\n */    
            len += (last - p + 2); 
        }
    }

    buf = ngx_palloc(r->pool, len);
    if (buf == NULL) {

        return NGX_ERROR;
    }

    last = buf;
    last = ngx_copy(last, "#EXTM3U\r\n", 9);
    last = ngx_copy(last, "#EXT-X-VERSION:3\r\n", 18);
    last = ngx_sprintf(last, "#EXT-X-TARGETDURATION:%d\r\n", m);
    last = ngx_sprintf(last, "#EXT-X-MEDIA-SEQUENCE:%d\r\n", sequence);

    size = base.len + 1 + stream->len + 8 + 1 + 12 + 1;
    path = ngx_pnalloc(r->pool, size);
    if (path == NULL) {
        return NGX_ERROR;
    }

    for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) 
    {
        if (*p == 0x20) {
            continue;
        }

        extid = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, '#');
        q = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (NULL == q && NULL == extid) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
            return NGX_ERROR;        
        }

        if(extid != NULL)
        {
            rsa.data = p;
            rsa.len = 265;
        }
        else if(q != NULL)
        {
            n = ngx_atoi(q + 1, 2);
            value.data = p;
            value.len = q - p;
        }

        if(q != NULL && rsa.len > 0)
        {
            q = ngx_copy(path, base.data, base.len);
            q = ngx_sprintf(q, "%V", &value);
            *q = 0;

            //检测文件是否存在;
            /*rc = ngx_file_info(path, &fi);
            if (rc == NGX_FILE_ERROR) 
            {
                ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, path);
                continue;
            }*/

            last = ngx_sprintf(last, "#EXTINF:%d,\r\n", n);
            last = ngx_sprintf(last, "%V\r\n%V\r\n", &rsa, &value);
            rsa.len = 0;
        }
    }

    b->pos = buf;
    b->last = last;
    b->memory = 1;
    b->start = buf;
    b->end = buf + len;
    b->last_buf = 1;
    b->last_in_chain = 1;

    return NGX_OK;
}
