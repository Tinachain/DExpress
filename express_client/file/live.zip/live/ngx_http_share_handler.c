#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>
#include <ngx_md5.h>

/* handle ffmpeg's bug */
#define FFMPEG_RETRY_TIMES 3

//static ngx_str_t publish_uri = ngx_string("/content/publish");

typedef struct {
    ngx_uint_t                done;
    ngx_uint_t                status;
    ngx_http_request_t       *subrequest;
    u_char                    key[32];
    size_t                    len;
    
    ngx_int_t                 start;
    ngx_int_t                 duration;
} ngx_http_share_request_ctx_t;

static ngx_str_t ngx_http_live_no_cache = ngx_string("no-cache");
static ngx_int_t
ngx_http_live_add_cache_control(ngx_http_request_t *r, ngx_str_t *value);
static ngx_int_t ngx_http_share_dynamic_offset(ngx_http_request_t *r, 
    ngx_int_t *offset);
static ngx_int_t ngx_http_live_m3u8_create_dir_cmd(ngx_http_request_t *r,  ngx_str_t *cmd);
static ngx_int_t ngx_http_live_m3u8_delete_dir_cmd(ngx_http_request_t *r,  ngx_str_t *cmd);

static ngx_int_t ngx_http_live_m3u8_start_cmd(ngx_str_t *cmd);
/*static ngx_int_t
ngx_http_share_request_done(ngx_http_request_t *r, void *data, ngx_int_t rc)
{
    ngx_http_share_request_ctx_t   *ctx = data;

	if (ctx == NULL) {
		 return NGX_ERROR;
	}
    
    ctx->status = rc;
    r->parent->write_event_handler = ngx_http_core_run_phases;
    ctx->status = r->headers_out.status;	
    r->parent->headers_out.status = r->headers_out.status;
    ctx->done = 1;
    
    return rc;
}*/

#if 0
static ngx_int_t
ngx_http_share_create_request(ngx_http_request_t *r, ngx_buf_t *b, 
    ngx_http_share_request_ctx_t *ctx)
{
    u_char                     *last, *buf;
    size_t                      len;
    ngx_http_live_m3u8_conf_t  *hlcf;

    /*
	{"path":"path","urls":["url1","url2","url3"],"id":0, "response_address":"42.159.240.197:8080/otvcloud/BackServlet"}
	*/
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
  
    len = 1;  /* { */  
    
    /* path */
    len += 6; /* "path" */
    len++; /* : */
    len++; /* " */
    len += ctx->len;
    len += 7;
    len++; /* " */

    len++; /* , */
    len += 6; /* "urls" */
    len++;  /* : */
    len++;  /* [ */
    
    /* urls */
    /* m3u8 */
    len++;  /* " */
    len += 7; /* http:// */
    len += hlcf->localhost.len;
    len += ctx->len;
    len += 7; /* 1/22/1/ */
    len += 10; /* index.m3u8 */
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */
    
    len++; /* " */
    /* logo jpg */
    len++; /* , */
    len++; /* " */
    len += 7; /* http:// */
    len += hlcf->localhost.len;
    len += ctx->len;
    len += 7; /* 1/22/1/ */
    len += 8; /* logo.jpg */
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */

    len++; /* " */
    len++; /* ] */
    
    len++; /* , */
    len += 6; /* "id":0, */
    
    len++; /* , */
    len += 18; /* "response_address" */
    len++; /* : */
    len++; /* " */
    len += hlcf->share_resp.len;
    len++; /* " */
    
    len++; /* } */
    
    buf = ngx_palloc(r->pool, len);
    if (buf == NULL) {
        return NGX_ERROR;
    }
    
    last = buf;
    
    *last++ = '{';
    last = ngx_copy(last, (u_char *) "\"path\"", 6);
    *last++ = ':';
    *last++ = '"';
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    *last++ = '"';
    
    *last++ = ',';
    last = ngx_copy(last, (u_char *) "\"urls\"", 6);
    *last++ = ':';
    *last++ = '[';

    *last++ = '"';
    last = ngx_copy(last, (u_char *) "http://", 7);
    last = ngx_copy(last, hlcf->localhost.data, hlcf->localhost.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    last = ngx_copy(last, (u_char *) "logo.jpg", 8);
    *last++ = '?';
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);
    
    *last++ = '"';
    
    *last++ = ',';
    *last++ = '"';
    last = ngx_copy(last, (u_char *) "http://", 7);
    last = ngx_copy(last, hlcf->localhost.data, hlcf->localhost.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    last = ngx_copy(last, (u_char *) "index.m3u8", 10);
    *last++ = '?';
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);

    *last++ = '"';
    *last++ = ']';

    len++; /* , */
    len += 7; /* "id":0, */
    
    *last++ = ',';
    last = ngx_copy(last, (u_char *) "\"id\":0", 6);
    
    *last++ = ',';
    last = ngx_copy(last, "\"response_address\"", 18);
    *last++ = ':';
    *last++ = '"';
    last = ngx_copy(last, hlcf->share_resp.data, hlcf->share_resp.len);
    *last++ = '"';

    *last++ = '}';
    
    b->start = buf;
    b->end = buf + len;
    b->pos = buf;
    b->last = last;
    b->memory = 1;
    b->last_buf = 1;

    return NGX_OK;    
}

#endif


static ngx_int_t
ngx_http_live_add_cache_control(ngx_http_request_t *r, ngx_str_t *value)
{
    ngx_table_elt_t *cc, **ccp;

    if (value->len == 0) {
        return NGX_OK;
    }

    ccp = r->headers_out.cache_control.elts;

    if (ccp == NULL) {

        if (ngx_array_init(&r->headers_out.cache_control, r->pool, 1,
                sizeof(ngx_table_elt_t *)) != NGX_OK) {
            return NGX_ERROR;
        }
    }

    ccp = ngx_array_push(&r->headers_out.cache_control);
    if (ccp == NULL) {
        return NGX_ERROR;
    }

    cc = ngx_list_push(&r->headers_out.headers);
    if (cc == NULL) {
        return NGX_ERROR;
    }

    cc->hash = 1;
    ngx_str_set(&cc->key, "Cache-Control");
    cc->value = *value;

    *ccp = cc;

    return NGX_OK;
}

static ngx_int_t
ngx_http_share_create_body(ngx_http_request_t *r, ngx_buf_t *b, 
    ngx_http_share_request_ctx_t *ctx)
{	
    u_char                    *buf, *last;
    ngx_int_t                  len;
    ngx_http_live_m3u8_conf_t *hlcf;
	ngx_int_t i = 0;
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
	
    last = (u_char *) ngx_strchr(r->unparsed_uri.data, '?');
	
	
    len = sizeof("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") - 1;
    len += sizeof("<root>") - 1;
    len += 11;      /* "<share_uri>" */
    len += 9; /* <![CDATA[ */
    len += 7;       /* http:// */
    len += hlcf->origin.len; /*ip:port */
    len += ctx->len;
    len += 36; /* 1/22/1/ */
    len += 10; /* index.m3u8 */
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */
    len += 3; /* ]]> */
    len += 12;    /* "</share_uri>" */
    len += 16;     /* "<share_logo_uri>" */
    len += 9; /* <![CDATA[ */

    len += 7;/* http:// */
    len += hlcf->origin.len; /*ip:port */
    len += ctx->len;
    len += 36; /* 1/22/1/ */
    len += 8; /* logo.jpg */ 
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */
    len += 3; /* ]]> */

    len += 17;    /* "</share_logo_uri>" */
    len += sizeof("</root>") - 1;
	
    buf = ngx_palloc(r->pool, len);
    if (buf == NULL) {
        return NGX_ERROR;
    }
	
    last = buf;
    last = ngx_copy(last, 
					"<?xml version=\"1.0\" encoding=\"UTF-8\"?>", 
					sizeof("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") - 1);
					
    last = ngx_copy(last, "<root>", 6);
    last = ngx_copy(last, "<share_uri>", 11);
    last = ngx_copy(last, "<![CDATA[http://", 16);
    last = ngx_copy(last, hlcf->origin.data, hlcf->origin.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    for(i = 4; i< 32;i++){
        *last++ = ctx->key[i];
    }
    *last++ = '/';
    last = ngx_copy(last, "index.m3u8", 10);
    *last++ = '?';					
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);

    last = ngx_copy(last, "]]></share_uri>", 15);

    last = ngx_copy(last, "<share_logo_uri>", 16);
    last = ngx_copy(last, "<![CDATA[http://", 16);
    last = ngx_copy(last, hlcf->origin.data, hlcf->origin.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    for(i = 4; i< 32;i++){
        *last++ = ctx->key[i];
    }
    *last++ = '/';
    last = ngx_copy(last, "logo.jpg", 8);
    *last++ = '?';					
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);

    last = ngx_copy(last, "]]></share_logo_uri>", 20);
    last = ngx_copy(last, "</root>", sizeof("</root>") - 1);

    b->start = buf;
    b->end = buf + len;
    b->pos = buf;
    b->last = last;
    b->memory = 1;
    b->last_buf = 1;
    b->last_in_chain = 1;
	
    return NGX_OK;
}



static ngx_int_t
ngx_http_share_create_zip_body(ngx_http_request_t *r, ngx_buf_t *b, 
    ngx_http_share_request_ctx_t *ctx)
{	
    u_char                               *buf, *last;
    ngx_int_t                             len, i;

    ngx_http_live_m3u8_conf_t *hlcf;
	
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
	
    last = (u_char *) ngx_strchr(r->unparsed_uri.data, '?');
	

    len = sizeof("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") - 1;
    len += sizeof("<root>") - 1;
    len += 11;      /* "<share_uri>" */
    len += 9; /* <![CDATA[ */
    len += 7;       /* http:// */
    len += hlcf->origin.len; /*ip:port */
    len += ctx->len;
    len += 36; /* 1/22/1/ */
    len += 10; /* index.m3u8 */
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */
    len += 3; /* ]]> */
    len += 12;    /* "</share_uri>" */
    len += 16;     /* "<share_logo_uri>" */
    len += 9; /* <![CDATA[ */

    len += 7;/* http:// */
    len += hlcf->origin.len; /*ip:port */
    len += ctx->len;
    len += 36; /* 1/22/1/ */
    len += 8; /* logo.jpg */ 
    len++; /* ? */
    len += 6; /* start= */
    len += 10; /* 290211839 */
    len++;     /* & */
    len += 4; /* len= */
    len += 4; /* 300 */
    len += 3; /* ]]> */

    len += 17;    /* "</share_logo_uri>" */
    len += sizeof("</root>") - 1;
	
    buf = ngx_palloc(r->pool, len);
    if (buf == NULL) {
        return NGX_ERROR;
    }
	
    last = buf;
    last = ngx_copy(last, 
					"<?xml version=\"1.0\" encoding=\"UTF-8\"?>", 
					sizeof("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") - 1);
					
    last = ngx_copy(last, "<root>", 6);
    last = ngx_copy(last, "<share_uri>", 11);
    last = ngx_copy(last, "<![CDATA[http://", 16);
    last = ngx_copy(last, hlcf->origin.data, hlcf->origin.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    for(i = 4; i< 32;i++){
        *last++ = ctx->key[i];
    }
    *last++ = '/';
    last = ngx_copy(last, "index.m3u8", 10);
    *last++ = '?';					
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);

    last = ngx_copy(last, "]]></share_uri>", 15);

    last = ngx_copy(last, "<share_logo_uri>", 16);
    last = ngx_copy(last, "<![CDATA[http://", 16);
    last = ngx_copy(last, hlcf->origin.data, hlcf->origin.len);
    last = ngx_copy(last, r->uri.data, ctx->len);
    *last++ = ctx->key[0];
    *last++ = '/';
    *last++ = ctx->key[1];
    *last++ = ctx->key[2];
    *last++ = '/';
    *last++ = ctx->key[3];
    *last++ = '/';
    for(i = 4; i< 32;i++){
        *last++ = ctx->key[i];
    }
    *last++ = '/';
    last = ngx_copy(last, "logo.zip", 8);
    *last++ = '?';					
    last = ngx_sprintf(last, "start=%d", ctx->start);
    *last++ = '&';
    last = ngx_sprintf(last, "len=%d", ctx->duration);

    last = ngx_copy(last, "]]></share_logo_uri>", 20);
    last = ngx_copy(last, "</root>", sizeof("</root>") - 1);

    b->start = buf;
    b->end = buf + len;
    b->pos = buf;
    b->last = last;
    b->memory = 1;
    b->last_buf = 1;
    b->last_in_chain = 1;
	
    return NGX_OK;
}


ngx_int_t 
ngx_http_share_handler(ngx_http_request_t *r)
{
    ngx_int_t                      rc, test, offset;
    ngx_buf_t                     *b;
//    ngx_http_request_t            *sr;
//    ngx_http_post_subrequest_t    *ps;
    ngx_http_share_request_ctx_t  *ctx;
    ngx_chain_t                   *out;
    ngx_http_live_m3u8_conf_t     *hlcf;
    ngx_str_t                      value;
    time_t                         now, start, len, modify;
    ngx_md5_t                      md5;
    u_char                        *last, key[16];

    len = 0;
    offset = 0;
    test = 0;

    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                   "share request handler");

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);

    ctx = ngx_http_get_module_ctx(r, ngx_http_live_m3u8_module);


    /* we response to 'GET' and 'HEAD' requests only */
    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }
 
    /* discard request body, since we don't need it here */
    rc = ngx_http_discard_request_body(r);
    if (rc != NGX_OK) {
        return rc;
    }

   if (ctx == NULL) {
       ctx = ngx_pcalloc(r->pool, sizeof(ngx_http_share_request_ctx_t));  
    }
   
    /* paramter check */
    if (r->args.len == 0) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    now = ngx_time();
    
    /* modify= */
    modify = 0;
    if (ngx_http_arg(r, (u_char *) "modify", 6, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    } 

    modify = ngx_atotm(value.data, value.len);
    if (modify == NGX_ERROR) {
        modify = 0;
    }
    
    /* try= */
    test = 1;
    if (ngx_http_arg(r, (u_char *) "attempt", 7, &value) == NGX_OK) {
        test = ngx_atoi(value.data, value.len);
        if (test == NGX_ERROR) {
            test = 1;
        }
    }

    /* offset= */
    if (ngx_http_arg(r, (u_char *) "offset", 6, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    } 

    len = ngx_atotm(value.data, value.len);
    if (len == NGX_ERROR || len == 0) {
        len = hlcf->default_length;
    }
    
    if (len > hlcf->max_length) {
        len = hlcf->max_length;
    }

    if (ngx_http_arg(r, (u_char *) "starttime", 9, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    }

    offset = hlcf->time_offset;

    /* get dynamic offset */
    if (hlcf->dynamic_offset) {
            rc = ngx_http_share_dynamic_offset(r, &offset);
            if (rc == NGX_ERROR) {
                offset = hlcf->time_offset;
            }
    }
    printf("offset:%ld\n", offset); 
	
    start = ngx_http_live_m3u8_timestamp(&value, 0);

    if ( test ) {

        if (hlcf->dynamic_offset && offset > 0 && rc != NGX_ERROR) {	
		if (start < now && now - start > 180) { /*review share*/
			start = start - len;
			printf("review share!\n");
			
		} else { /*live share*/
		
			start = rc - len;
			printf("live share!last segment time > system time!\n");
		}	

        } else {
        
		if (start < now && now - start > 180) {/*review share*/
		    start = start - len;
			printf("review share!\n");
			
		} else { /*live share*/
		
			start = ngx_http_live_m3u8_timestamp(&value, offset - len/* - modify*/);
			printf("live share!last segment time < system time,or not danamic offset check!!!\n");
		}
	 }
		
    }else {

        start = start + offset - len;
    }
	
    if (start == NGX_ERROR) {
       return NGX_HTTP_BAD_REQUEST;
    }
    /* 7 * 86400 : 7 days */
    if (start < now - NGX_LIVE_MEU8_MAX_TIME) {
       return NGX_HTTP_BAD_REQUEST;
    }
    
    ctx->start = start;
    ctx->duration = len;

    ngx_md5_init(&md5);
    ngx_md5_update(&md5, r->uri.data, r->uri.len);
    ngx_md5_update(&md5, r->args.data, r->args.len);
    ngx_md5_final(key, &md5);
    ngx_hex_dump(ctx->key, key, 16);
    
    last = r->uri.data + r->uri.len;
    last--;
    for (; last != r->uri.data; last--) {
        if (*last == '/') {
            break;
        }
    }
    
    ctx->len = last - r->uri.data;
    ctx->len++;

    r->headers_out.content_type_len = sizeof("text/xml") - 1;
    r->headers_out.content_type.data = (u_char *) "text/xml";
 
    /* create response body */
    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
	
   if ( ( test == 1) && (len < 20 * 60) ){ 
      if (ngx_http_share_create_zip_body(r, b, ctx) != NGX_OK) {
           return NGX_HTTP_INTERNAL_SERVER_ERROR;
       }
	
    } else  {

      if (ngx_http_share_create_body(r, b, ctx) != NGX_OK) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }
    }
	
    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);

    /* send the header only, if the request type is http 'HEAD' */
    if (r->method == NGX_HTTP_HEAD) {     
        return ngx_http_send_header(r);
    }

    out = ngx_pcalloc(r->pool, sizeof(ngx_chain_t));   
    if (out == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    out->buf = b;
    out->next = NULL;
 
    /* send the headers of your response */
    rc = ngx_http_send_header(r);
 
    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }
 
    ngx_http_output_filter(r, out);

    return NGX_DONE;



/*


    ps = ngx_palloc(r->pool, sizeof(ngx_http_post_subrequest_t));
    if (ps == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    ps->handler = ngx_http_share_request_done;
    ps->data = ctx;

    if (ngx_http_subrequest(r, &publish_uri, NULL, &sr, ps,
                            NGX_HTTP_SUBREQUEST_WAITED)
        != NGX_OK)
    {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    sr->request_body = ngx_pcalloc(r->pool, sizeof(ngx_http_request_body_t));
    if (sr->request_body == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_share_create_request(r, b, ctx) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
 
    out = ngx_pcalloc(r->pool, sizeof(ngx_chain_t));   
    if (out == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    out->buf = b;
    out->next = NULL;

    sr->request_body->bufs = out;
    sr->headers_in.content_length_n = ngx_buf_size(b);

    ctx->subrequest = sr;
    ngx_http_set_ctx(r, ctx, ngx_http_live_m3u8_module);
*/	
}

ngx_int_t
ngx_http_live_m3u8_build_mp4(ngx_http_request_t *r, ngx_buf_t *b,
    ngx_str_t *stream, time_t start, time_t duration, ngx_int_t share, ngx_int_t ntype)
{
    ngx_uint_t                 cmdlen, buflen;
    u_char                    *plast, *p, *q, *buf, *data;
    ngx_file_info_t            fi;
    ngx_int_t                  rc;
    ngx_uint_t                 i;
    size_t                     root;
    ngx_str_t                  base, value;
    ngx_str_t                  cmd;
    sighandler_t               old_handler;
    ngx_http_core_loc_conf_t   *clcf;
    int                        temp_num;
    ngx_http_live_m3u8_conf_t  *hlcf;


    u_char                     tsname[128] = {0};
    char                       smp4[32] = {0};
    char                       sconcatfile[32] = {0};
	u_char                    *ptmp = NULL;
    char                      *pffmpegstart = "/usr/local/ffmpeg/bin/ffmpeg -f concat  -safe 0 -i ";
    int                        nffmpegstart = strlen(pffmpegstart);
    char                      *pffmpegflag = NULL;
    int                        nffmpegflag = 0;
    int                        nffmpegextra = 0;
    
    temp_num = ngx_atomic_fetch_add(ngx_temp_number, 1);
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);

    ngx_log_error(NGX_LOG_INFO, r->connection->log, ngx_errno,
                          "in build mp4,s:%d,d:%d", start, duration);
    if(hlcf->hls2mp4_logo){
      pffmpegflag = " -vcodec h264 -acodec copy -vf \"movie=/usr/local/nginx/sbin/log.png , \
      scale=128:128[watermark]; [in][watermark]    \
          overlay=main_w-overlay_w-10:10 [out]\" -movflags faststart -y ";
      nffmpegflag   = strlen(pffmpegflag);   
    }else{
      pffmpegflag = " -vcodec copy -acodec copy -movflags faststart -y ";
      nffmpegflag = strlen(pffmpegflag);
    }
    nffmpegextra = strlen(" -bsf:a aac_adtstoasc ");
                          
    /*get cur time*/
    time_t now;
	struct tm  *timenow;
	time(&now);
	timenow = localtime(&now);

 	sprintf(smp4, "%d%02d%02d%02d%02d%02d%d.", timenow->tm_year+1900,timenow->tm_mon+1, timenow->tm_mday,
 	timenow-> tm_hour, timenow-> tm_min,  timenow-> tm_sec, temp_num);
 		
    sprintf(sconcatfile, "%s.txt", smp4);
 	
    if(ntype == 0){
        strcat(smp4,"mp4");
    } else if(ntype == 1){
        strcat(smp4,"mov");;
    }else if(ntype == 2){
         strcat(smp4,"ts");
    }else if(ntype == 3){
         strcat(smp4,"flv");
    }else if(ntype == 4){
         strcat(smp4,"avi");
    }
	cmdlen = buflen = rc = 0;
	
    clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);
    data = ngx_palloc(r->pool, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (data == NULL) {
        return NGX_ERROR;
    }

    plast = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (plast == NULL) {
        return NGX_ERROR;
    }

    for (p = plast - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }

    base.len -= (plast - p);

    rc = ngx_http_live_m3u8_get_index(r, &base, start, stream, duration, NGX_LIVE, data);
    if (rc == NGX_ERROR) {
        return NGX_ERROR;
    }

     /*get len*/
    cmdlen =  nffmpegstart;     //-i
    cmdlen += base.len + 40;    //path/20161024000030.mp4.txt
    cmdlen+=  nffmpegflag;      // avcodec
    cmdlen += nffmpegextra;     //fiters
    cmdlen += base.len + 40;    //path/20161024000030.mp4
 
    /*------------------make ffmpeg concat txt--------------------*/
    //allocate tmp buf
    buflen = 30 + base.len + NGX_LIVE_M3U8_INDEX_LINE_SIZE;
    buf = ngx_pnalloc(r->pool, buflen);
    if (buf == NULL) {
        return NGX_ERROR;
    }

    //get prefix
    for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
        if (*p == 0x20) {
            continue;
        }
        if(ngx_strlen(tsname) == 0){
               //refer to  replay.txt 这里暂放，由于亦分享已经不再使用 fxh7622;
               strncpy((char*)tsname, (char*)p, 40-9);  
               break;
        }
    }
    
    //make ffmpeg concat txt path
    ngx_memzero(buf, buflen);
    q = buf;
    q = ngx_copy(q, base.data, base.len);
    ptmp = (u_char*)strrchr((char*)tsname, '/');
    if(ptmp  != NULL){
       q = ngx_copy(q, tsname, ptmp-tsname + 1);
    }
    q = ngx_copy(q, sconcatfile, strlen(sconcatfile));
    *q = 0;
    
    //add ts to ffmpeg concat txt
    FILE*fp = fopen((char*)buf,"wb"); 
    if(fp != NULL){
          for (i = 0, p = data; i < (ngx_uint_t) duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
            if (*p == 0x20) {
                continue;
            }
            q = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
            if (q == NULL) {
                ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
                return NGX_ERROR;
            }

            value.data = p;
            value.len = q - p;

             /*path : /xxxx/.../x.ts*/
            q = ngx_copy(buf, base.data, base.len);
            q = ngx_sprintf(q, "%V", &value);
            *q = 0;

            rc = ngx_file_info(buf, &fi);
            if (rc == NGX_FILE_ERROR) {
                ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, buf);
                continue;
            }
           fprintf(fp,"file '%s'\n",buf);
        }
        fclose(fp);
        fp = NULL;
    }else{
        ngx_log_error(NGX_LOG_DEBUG, r->connection->log, ngx_errno, "%s openfile faild" , "file");
        return NGX_ERROR;
    }

    /*make ffmpeg cmd*/
    cmd.data = ngx_palloc(r->pool, cmdlen);
    if (cmd.data == NULL) {
        return NGX_ERROR;
    }
    ngx_memzero(cmd.data, cmdlen);
    
    plast = cmd.data;
    plast = ngx_copy(plast, pffmpegstart, nffmpegstart);
    
    //make concat txt
    ngx_memzero(buf, buflen);
    q = buf;
    q = ngx_copy(q, base.data, base.len);
    ptmp = (u_char*)strrchr((char*)tsname, '/');
    if(ptmp  != NULL){
       q = ngx_copy(q, tsname, ptmp-tsname + 1);
    }
    q = ngx_copy(q, sconcatfile, strlen(sconcatfile));
    *q = 0;

    plast = ngx_copy(plast, buf, strlen((char*)buf));
    *plast = 0;
   
    //add  ffmpeg args
    plast = ngx_copy(plast, pffmpegflag, nffmpegflag);
    if(ntype != 2){
        plast = ngx_copy(plast, " -bsf:a aac_adtstoasc ", nffmpegextra);
    }
    
    //make out mp4 path
    ngx_memzero(buf, buflen);
    q = buf;
    q = ngx_copy(q, base.data, base.len);
    ptmp = (u_char*)strrchr((char*)tsname, '/');

    if(ptmp  != NULL){
       q = ngx_copy(q, tsname, ptmp-tsname+1);
    }
    q = ngx_copy(q, smp4, strlen(smp4));
    *q = 0;

    plast = ngx_copy(plast, buf, strlen((char*)buf));
    *plast = 0;

    cmd.len = plast - cmd.data;
    
    ngx_log_error(NGX_LOG_DEBUG, r->connection->log, ngx_errno, "ffmpeg cmd: %V" , &cmd);
                          
   for (i = 0; i < FFMPEG_RETRY_TIMES; i++) {
    	old_handler = signal(SIGCHLD, SIG_DFL);

        rc = ngx_http_live_m3u8_start_cmd(&cmd);
        if (rc == NGX_OK) {
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "make mp4 ok\n");
            signal(SIGCHLD, old_handler);
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "make mp4 error:%d ,%V\n", (int) rc, &cmd);

        signal(SIGCHLD, old_handler);
    }

    if (i >= FFMPEG_RETRY_TIMES) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "make mp4 try time out of range\n");
        return NGX_ERROR;
    }


   /*make http mp4 path*/
    ngx_memzero(buf, buflen);
    q = ngx_sprintf(buf, "http://%V", &hlcf->mergemp4_local_addr);
    q = ngx_copy(q, base.data+clcf->root.len, base.len - clcf->root.len);
    if(ptmp  != NULL){
       q = ngx_copy(q, tsname, ptmp - tsname + 1);
    }
    q = ngx_copy(q, smp4, strlen(smp4));
    *q = 0;
    buflen = q - buf;

    ngx_str_t ret;
    ret.data = buf;
    ret.len = buflen;
    ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "mp4 ret:%V\n", &ret);

    b->pos = buf;
    b->last = q;
    b->memory = 1;
    b->start = buf;
    b->end = buf + buflen;
    b->last_buf = 1;
    b->last_in_chain = 1;

    return NGX_OK;
}
ngx_int_t ngx_http_share_m3u8_getmt(ngx_http_request_t *r, ngx_str_t mt){
 ngx_int_t  ntype = -1;
  if (ngx_strncmp(mt.data, "mp4", 3) == 0) {
    ntype = 0;
  }else if (ngx_strncmp(mt.data, "mov", 3) == 0) {
    ntype = 1;
  }else if (ngx_strncmp(mt.data, "ts", 2) == 0) {
    ntype = 2;
  }else if (ngx_strncmp(mt.data, "flv", 3) == 0) {
    ntype = 3;
  }else if (ngx_strncmp(mt.data, "avi", 3) == 0) {
    ntype = 4;
  }else{
     ngx_log_error(NGX_LOG_INFO, r->connection->log, ngx_errno, "makemp4 no support %V", &mt);
  }
  return ntype;
}

ngx_int_t 
ngx_http_share_m3u8_handler(ngx_http_request_t *r)
{
    u_char                    *last;
    time_t                     start, len;
    size_t                     root;
    ngx_int_t                  rc;
    ngx_uint_t                 level;
    ngx_str_t                  path, stream, value, mt;
    ngx_log_t                 *log;
    ngx_buf_t                 *b;
    ngx_chain_t                out;
    ngx_open_file_info_t       of;
    ngx_http_core_loc_conf_t  *clcf;
    ngx_http_live_m3u8_conf_t *hlcf;

    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

    if (r->args.len == 0) {
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "start", 5, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    start = ngx_atotm(value.data, value.len);

    if (start == NGX_ERROR) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (ngx_http_arg(r, (u_char *) "len", 3, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    len = ngx_atotm(value.data, value.len);

    if (len == NGX_ERROR) {
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "merge", 5, &mt) != NGX_OK) {
        //return NGX_HTTP_BAD_REQUEST;
    }

    r->root_tested = !r->error_page;

    if (ngx_http_test_stream_type(r, &hlcf->metas, &stream)) {

        b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
        if (b == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        goto meta;

    } else if (ngx_http_test_stream_type(r, &hlcf->streams, &stream)) {

        b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
        if (b == NULL) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

         if (mt.len == 3 && ngx_strncmp(mt.data, "mp4", 3) == 0) {
            ngx_int_t ntype = ngx_http_share_m3u8_getmt(r, mt);
            if(ntype != -1){
                rc = ngx_http_live_m3u8_build_mp4(r, b, &stream, start, len, 1, ntype);
            }
         }else{
                 rc = ngx_http_live_m3u8_build_playlist(r, b, &stream, start, len, 1);
         }

        if (rc == NGX_ERROR) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        goto done;

    } else {

        return NGX_DECLINED;
    }

meta:
    
    last = ngx_http_map_uri_to_path(r, &path, &root, 0);
    if (last == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    path.len = last - path.data;

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, log, 0, "http share filename: \"%V\"", &path);

    clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);

    ngx_memzero(&of, sizeof(ngx_open_file_info_t));

    of.read_ahead = clcf->read_ahead;
    of.directio = clcf->directio;
    of.valid = clcf->open_file_cache_valid;
    of.min_uses = clcf->open_file_cache_min_uses;
    of.errors = clcf->open_file_cache_errors;
    of.events = clcf->open_file_cache_events;

    if (ngx_http_set_disable_symlinks(r, clcf, &path, &of) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_open_cached_file(clcf->open_file_cache, &path, &of, r->pool) != NGX_OK)
    {
        switch (of.err) {

        case 0:
            return NGX_HTTP_INTERNAL_SERVER_ERROR;

        case NGX_ENOENT:
        case NGX_ENOTDIR:
        case NGX_ENAMETOOLONG:

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_NOT_FOUND;
            break;

        case NGX_EACCES:
#if (NGX_HAVE_OPENAT)
        case NGX_EMLINK:
        case NGX_ELOOP:
#endif

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_FORBIDDEN;
            break;

        default:

            level = NGX_LOG_CRIT;
            rc = NGX_HTTP_INTERNAL_SERVER_ERROR;
            break;
        }

        if (rc != NGX_HTTP_NOT_FOUND || clcf->log_not_found) {
            ngx_log_error(level, log, of.err, "%s \"%s\" failed", of.failed, path.data);
        }

        return rc;
    }

    if (!of.is_file) {

        if (ngx_close_file(of.fd) == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ALERT, log, ngx_errno, ngx_close_file_n " \"%s\" failed", path.data);
        }

        return NGX_DECLINED;
    }

    rc = ngx_http_live_m3u8_build_index(r, &of, &r->args, b);
    
    if (rc == NGX_ERROR){        
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

done:

    log->action = "sending live_m3u8 to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);
    r->headers_out.last_modified_time = of.mtime;

    if (ngx_http_set_etag(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;
    ngx_http_live_add_cache_control(r, &ngx_http_live_no_cache);
    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);
}


static ngx_int_t
ngx_http_live_m3u8_start_cmd(ngx_str_t *cmd)
{
    FILE     *fp; 
    u_char    buf[1024];

    if (cmd == NULL || cmd->data == NULL) { 
        printf("my_system cmd is NULL!\n");
        return NGX_ERROR;
    } 
    printf("cmd:%s\n", (char *) cmd->data);
    if ((fp = popen((char *) cmd->data, "r") ) == NULL) { 	
        printf("popen error\n");		
        return NGX_ERROR; 
    }
	
    while (fgets((char *) buf, sizeof(buf), fp)) {
        printf("%s\n",(char *) buf);	
    }

    pclose(fp);
    return 0;
}



static ngx_int_t
ngx_http_live_m3u8_zip_start_cmd(ngx_str_t *cmd)
{
    FILE     *fp; 
    u_char    buf[1024];

    if (cmd == NULL || cmd->data == NULL) { 
        printf("my_system cmd is NULL!\n");
        return NGX_ERROR;
    } 
    printf("cmd:%s\n", (char *) cmd->data);
    if ((fp = popen((char *) cmd->data, "r") ) == NULL) { 	
		printf("popen error\n");		
        return NGX_ERROR; 
    }
	
    while (fgets((char *) buf, sizeof(buf), fp)) {
        printf("%s\n",(char *) buf);	
    }

    return pclose(fp);
}

static ngx_int_t
ngx_http_live_ts2jpg_url(ngx_http_request_t *r, ngx_str_t file, ngx_buf_t *b, ngx_str_t *local_addr)
{
    u_char                    *last, *p, *buf, *seprate;
    ngx_str_t                  cmd, out,out_send;
    sighandler_t               old_handler;
    ngx_fd_t                   fd;
    //ngx_file_info_t            info;
    ngx_atomic_uint_t          n;
    ngx_int_t                  len, i, rc;
	ngx_http_live_m3u8_conf_t *hlcf;

	ngx_http_core_loc_conf_t  *clcf;

    fd = -1;
    buf = NULL;
	
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    p = file.data + file.len;
    p--;
	
    for (; p != file.data; p--) 
    {
        if (*p == '.') 
        {
	      break;
	    }
    }
	
    if (p == file.data) {
	 ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "file path error\n");
        return NGX_ERROR;
    }
	
    p++;
    len = p - file.data;
    len += 3;  
    len += 16;
    len ++;	
	
    out.data = ngx_palloc(r->pool, len);
    if (out.data == NULL) {
        return NGX_ERROR;
    }
	
    last = ngx_copy(out.data, file.data, p - file.data);
    n = ngx_atomic_fetch_add(ngx_temp_number, 1);
    last--;
    last = ngx_sprintf(last, "_%d.jpg", n);
	out.len = last - out.data;
    *last = 0;
   
    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "create_jpg:%V", &out);

    len = sizeof("/usr/local/ffmpeg/bin/getpic ") - 1; 
    len += file.len + 1; 
    len += out.len + 1;	
	len += hlcf->logo_resolution.len + 1; //sizeof("212 120 ") - 1; 
    len += sizeof("2>&1") - 1;
    len ++;
	
    cmd.data = ngx_palloc(r->pool, len);
    if (cmd.data == NULL) {
        return NGX_ERROR;
    }
    
    ngx_memzero(cmd.data, len);
    last = ngx_copy(cmd.data, "/usr/local/ffmpeg/bin/getpic ", sizeof("/usr/local/ffmpeg/bin/getpic ") - 1);
	last = ngx_copy(last, file.data, file.len);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, out.data, out.len);
	last = ngx_copy(last, " ", 1);
	seprate = (u_char *)ngx_strchr(hlcf->logo_resolution.data, 'x');
	if (seprate == NULL) {
		return NGX_ERROR;
	}
	last = ngx_copy(last, hlcf->logo_resolution.data, seprate - hlcf->logo_resolution.data);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, seprate + 1, hlcf->logo_resolution.data + hlcf->logo_resolution.len - seprate - 1);
    last = ngx_copy(last, " 2>&1", sizeof(" 2>&1") - 1);	
    cmd.len = last - cmd.data;				
    *last = 0;
	
    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) 
    {
    	old_handler = signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_start_cmd(&cmd);
        if (rc == NGX_OK) 
        {	
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic ok\n");		
			printf("get pic ok\n");
            signal(SIGCHLD, old_handler); 
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic error:%d\n", (int) rc);
        
        signal(SIGCHLD, old_handler); 
    }	
    
    if (i >= FFMPEG_RETRY_TIMES) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic try time out of range\n");
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic failed  cmd = %s\n",cmd.data );	
        return NGX_ERROR;
    }

	
	clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);
	out_send.data = ngx_pnalloc(r->pool, 128);
	if(out.len < clcf->root.len ){
		goto failed;
	}
    ngx_memcpy(out_send.data ,out.data + clcf->root.len, out.len - (clcf->root.len));
	out_send.len = out.len - clcf->root.len;
	
	buf = ngx_pcalloc(r->pool, 128);
	if (buf == NULL) {
        goto failed;
    }

	last = ngx_sprintf(buf, "http://%V%V", local_addr, &out_send);

    b->start = buf;
    b->end = buf + ngx_strlen(buf);
    b->pos = buf;
    b->last = b->end;
    b->memory = 1;
    b->last_buf = 1;

	ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get_pic duan buf =%s",last);
    
    return NGX_OK;
    
failed:
    
    if (fd != -1) 
    {
        if (ngx_close_file(fd) == NGX_FILE_ERROR) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "close picture error\n");
            printf("close picture error\n");	
        }
    
        if (ngx_delete_file(out.data) == NGX_FILE_ERROR) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete picture error\n");
            printf("delete picture error\n");	
        }
    }

    return NGX_ERROR;		
}

static ngx_int_t
ngx_http_live_ts2jpg(ngx_http_request_t *r, ngx_str_t file, ngx_buf_t *b)
{
    u_char                    *last, *p, *buf, *seprate;
    ngx_str_t                  cmd, out;
    sighandler_t               old_handler;
    ngx_fd_t                   fd;
    ngx_file_info_t            info;
    ngx_atomic_uint_t          n;
    ngx_int_t                  len, i, rc;
	ngx_http_live_m3u8_conf_t *hlcf;
	
    fd = -1;
    buf = NULL;
	
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    p = file.data + file.len;
    p--;
	
    for (; p != file.data; p--) 
    {
        if (*p == '.') 
        {
            break;
        }
    }
	
    if (p == file.data) 
    {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "file path error\n");
        return NGX_ERROR;
    }
	
    p++;
    len = p - file.data;
    len += 3;  
    len += 16;
    len ++;	
	
    out.data = ngx_palloc(r->pool, len);
    if (out.data == NULL) {
        return NGX_ERROR;
    }
	
    last = ngx_copy(out.data, file.data, p - file.data);
    n = ngx_atomic_fetch_add(ngx_temp_number, 1);
    last--;
    last = ngx_sprintf(last, "_%d.jpg", n);
	out.len = last - out.data;
    *last = 0;
   
    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "create_jpg:%V", &out);

    len = sizeof("/usr/local/ffmpeg/bin/getpic ") - 1; 
    len += file.len + 1; 
    len += out.len + 1;	
	len += hlcf->logo_resolution.len + 1; //sizeof("212 120 ") - 1; 
    len += sizeof("2>&1") - 1;
    len ++;
	
    cmd.data = ngx_palloc(r->pool, len);
    if (cmd.data == NULL) {
        return NGX_ERROR;
    }
    
    ngx_memzero(cmd.data, len);
    last = ngx_copy(cmd.data, "/usr/local/ffmpeg/bin/getpic ", sizeof("/usr/local/ffmpeg/bin/getpic ") - 1);
	last = ngx_copy(last, file.data, file.len);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, out.data, out.len);
	last = ngx_copy(last, " ", 1);
	seprate = (u_char *)ngx_strchr(hlcf->logo_resolution.data, 'x');
	if (seprate == NULL) {
		return NGX_ERROR;
	}
	last = ngx_copy(last, hlcf->logo_resolution.data, seprate - hlcf->logo_resolution.data);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, seprate + 1, hlcf->logo_resolution.data + hlcf->logo_resolution.len - seprate - 1);
    last = ngx_copy(last, " 2>&1", sizeof(" 2>&1") - 1);	
    cmd.len = last - cmd.data;				
    *last = 0;
	

    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) 
    {
    	old_handler = signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_start_cmd(&cmd);
        if (rc == NGX_OK) 
        {	
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic ok\n");		
			printf("get pic ok\n");
            signal(SIGCHLD, old_handler); 
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic error:%d\n", (int) rc);
        
        signal(SIGCHLD, old_handler); 
    }	
    
    if (i >= FFMPEG_RETRY_TIMES) {
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic try time out of range\n");
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic failed  cmd = %s\n",cmd.data );	
        return NGX_ERROR;
    }

    fd = ngx_open_file(out.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
    if (fd == NGX_INVALID_FILE) 
    {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "open picture error\n");
        printf("open picture error\n");
        return NGX_ERROR;
    }

    if (ngx_fd_info(fd, &info) == NGX_FILE_ERROR) 
    { 
        printf("open  fd info error\n");	
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get picture info error\n");
        goto failed;
    }
    
    buf = ngx_palloc(r->pool, info.st_size);
    if (buf == NULL) {
        goto failed;
    }
    
    if (read(fd, buf, info.st_size) == -1) { 
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "read picture error\n");
        printf("read picture error\n");	
        goto failed;
    }
    
    if (ngx_close_file(fd) == NGX_FILE_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "close picture error\n");
        printf("close picture error\n");	
    }

    if (ngx_delete_file(out.data) == NGX_FILE_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete picture error\n");
        printf("delete picture error\n");
    }
    
    b->start = buf;
    b->end = buf + info.st_size;
    b->pos = buf;
    b->last = b->end;
    b->memory = 1;
    b->last_buf = 1;
    
    return NGX_OK;
    
failed:
    
    if (fd != -1) {
        if (ngx_close_file(fd) == NGX_FILE_ERROR) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "close picture error\n");
            printf("close picture error\n");	
        }
    
        if (ngx_delete_file(out.data) == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete picture error\n");
            printf("delete picture error\n");	
        }
    }

    return NGX_ERROR;		
}

static ngx_int_t
ngx_http_live_mutil_ts2jpg(ngx_http_request_t *r, ngx_str_t file, ngx_str_t *zip_file, ngx_str_t *temp_dir)
{
    u_char                    *last, *p, *seprate;
    ngx_str_t                  cmd, out, dest_file;
    sighandler_t              old_handler_jpg;

    ngx_int_t                  len, i, rc;
	ngx_http_live_m3u8_conf_t *hlcf;
	
	hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
	
    p = file.data + file.len;
    p--;
	
    for (; p != file.data; p--) 
    {
        if (*p == '/') 
        {
            break;
        }
    }
	
    if (p == file.data) {
	 ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "file path error\n");
        return NGX_ERROR;
    }
	
    p++;
    len = file.len - (p - file.data);
    len -= 3;
    len ++;
	
    out.data = ngx_palloc(r->pool, len + 4);
    if (out.data == NULL) {
        return NGX_ERROR;
    }
    ngx_memzero(out.data, len + 4);


    last = ngx_copy(out.data, p, len - 1);
    last = ngx_copy(last, ".jpg", sizeof(".jpg") - 1);
    out.len = last - out.data;
    *last = 0;

    dest_file.len = temp_dir->len + out.len + 1;
    dest_file.data =  ngx_palloc(r->pool, dest_file.len);
    if (dest_file.data == NULL) {
        return NGX_ERROR;
    }  
    ngx_memzero(dest_file.data, dest_file.len);
	
    last = dest_file.data;
    last = ngx_snprintf(last, dest_file.len - 1, "%V%V", temp_dir, &out); 
    dest_file.len = last - dest_file.data;
    *last = 0;

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "create_jpg:%V", &out);

    len = sizeof("/usr/local/ffmpeg/bin/getpic ") - 1; 
    len += file.len + 1;  
    len += dest_file.len + 1;	
	len += hlcf->logo_resolution.len + 1;
    len += sizeof("2>&1") - 1;
    len ++;
	
    cmd.data = ngx_palloc(r->pool, len);
    if (cmd.data == NULL) {
        return NGX_ERROR;
    }
    ngx_memzero(cmd.data, len);
    last = ngx_copy(cmd.data, "/usr/local/ffmpeg/bin/getpic ",  sizeof("/usr/local/ffmpeg/bin/getpic ") - 1);
					
	last = ngx_copy(last, file.data, file.len);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, dest_file.data, dest_file.len);
	last = ngx_copy(last, " ", 1);
	seprate = (u_char *)ngx_strchr(hlcf->logo_resolution.data, 'x');
	if (seprate == NULL) {
		return NGX_ERROR;
	}
	last = ngx_copy(last, hlcf->logo_resolution.data, seprate - hlcf->logo_resolution.data);
	last = ngx_copy(last, " ", 1);
	last = ngx_copy(last, seprate + 1, hlcf->logo_resolution.data + hlcf->logo_resolution.len - seprate - 1);

    last = ngx_copy(last, " 2>&1", sizeof(" 2>&1") - 1);	
    cmd.len = last - cmd.data;				
    *last = 0;
	
    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) {
    	old_handler_jpg= signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_start_cmd(&cmd);
        if (rc == NGX_OK) {	
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic ok\n");		
			printf("get pic ok\n");
            signal(SIGCHLD, old_handler_jpg); 
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic error:%d\n", (int) rc);
        
        signal(SIGCHLD, old_handler_jpg); 
    }


    if (i >= FFMPEG_RETRY_TIMES) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic try time out of range\n");
        return NGX_ERROR;
    }
 
    return NGX_OK;
}


static ngx_int_t
ngx_http_live_m3u8_create_logo_jpg(ngx_http_request_t *r, ngx_str_t *stream, time_t start, time_t duration, ngx_buf_t *b)
{
    ngx_uint_t                 size;
    u_char                    *last, *p, *q, *path, *data;
    ngx_file_info_t            fi;
    ngx_int_t                  rc, i;
    size_t                     root;
    ngx_str_t                  base, value;


    data = ngx_palloc(r->pool, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (data == NULL) {
        return NGX_ERROR;
    }

    last = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (last == NULL) {
        return NGX_ERROR;
    }
    
    for (p = last - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }
    
    base.len -= (last - p);
    
    rc = ngx_http_live_m3u8_get_index(r, &base, start, stream, duration, NGX_LIVE, data);
    if (rc == NGX_ERROR) {
        return NGX_ERROR;
    }

    size = base.len + NGX_LIVE_M3U8_INDEX_LINE_SIZE;
    path = ngx_pnalloc(r->pool, size);
    if (path == NULL) {
        return NGX_ERROR;
    }
    
    rc = NGX_ERROR;
    
    for (i = 0, p = data; i < duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
        if (*p == 0x20) {
            continue;
        }

        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (last == NULL) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
			printf("replay.txt error\n");
            return NGX_ERROR;        
        }
        
        value.data = p;
        value.len = last - p;

        q = ngx_copy(path, base.data, base.len);
        q = ngx_sprintf(q, "%V", &value);
        *q = 0;
        value.data = path;
        value.len = q - path;
        
        rc = ngx_file_info(path, &fi);
    
        if (rc == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, path);
            continue;
        }
               
        break;                
    }
    
    if (rc == NGX_ERROR) {
        printf("can not find correct ts file\n");
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "can not find correct ts file\n");
        return NGX_ERROR;
    }
    
    if (ngx_http_live_ts2jpg(r, value, b) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic error\n");
        return NGX_ERROR;
    }

    return NGX_OK;
}


static ngx_int_t
ngx_http_live_m3u8_create_pic_jpg(ngx_http_request_t *r, ngx_str_t *stream, ngx_str_t *local_addr, time_t start, ngx_buf_t *b)
{
	ngx_uint_t				   size;
	u_char					 *last, *p, *q, *path, *data;
	ngx_file_info_t			  fi;
	ngx_int_t				  rc;
	size_t					  root;
	ngx_str_t				  base, value;
 
	data = ngx_pcalloc(r->pool,  NGX_LIVE_M3U8_INDEX_LINE_SIZE);
    if (data == NULL) {
        return NGX_ERROR;
    }
	
	last = ngx_http_map_uri_to_path(r, &base, &root, 0);
	if (last == NULL) {
	  return NGX_ERROR;
	}

	for (p = last - 1; p != base.data; p--) {
	  if (*p == '/') {
		  break;
	  }
	}

	base.len -= (last - p);

    // �жϵ�ǰʱ���m3u8�ļ���������ʱ�䣬����1���ӣ��ͷ���m3u8�ļ�δ���¡�
	//exzample: /var/www/lighttpd/channel01/700.m3u8
	time_t modify_time = 0, now = 0;
	ngx_str_t     file;
	FILE*         fp = NULL;
	ngx_int_t     result;
	struct stat   info;
	file.data = ngx_pcalloc(r->pool, base.len + 100); 
    last = ngx_sprintf(file.data, "%V%V.m3u8", &base, stream);
	file.len = last - file.data;
	*last = 0;
	fp = fopen((char*)file.data, "rb");
	if ( NULL == fp ) {
        ngx_log_error(NGX_LOG_EMERG, r->connection->log, ngx_errno, ngx_open_file_n " when checking: \"%s\" open failed", file.data);
        return NGX_ERROR;
    }
	
	result =stat((char*)file.data, &info );
	if(result == 0 ){
		modify_time = info.st_mtime;
	}    
	fclose(fp);
	fp = NULL;
	now = time((time_t*)NULL);
	if(now - modify_time > 60 )
	{
		last = ngx_sprintf(file.data + file.len, "target m3u8 not update");
		
		*last = 0;
		b->start = file.data;
		b->end = last;
		b->pos = file.data;
		b->last = last;
	    b->memory = 1;
        b->last_buf = 1;
		ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "the path \"%s\" not update for  %d s \" so get pic failed for live stream ", file.data, now - modify_time);
		return NGX_OK;
	}
	// �жϵ�ǰʱ���m3u8�ļ���������ʱ�䣬����1���ӣ��ͷ���m3u8�ļ�δ���¡��ж���ϡ�
	rc = ngx_http_live_m3u8_get_index_for_get_pic(r, &base, start, stream, data);
    if (rc == NGX_ERROR) {
        return NGX_ERROR;
    }

	size = base.len + NGX_LIVE_M3U8_INDEX_LINE_SIZE;
    path = ngx_pnalloc(r->pool, size);
    if (path == NULL) {
        return NGX_ERROR;
    }
    rc = NGX_ERROR;

	p = data;
    if (*p != 0x20) {
        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (last == NULL) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
			printf("replay.txt error\n");
            return NGX_ERROR;        
        }
        
        value.data = p;
        value.len = last - p;

        q = ngx_copy(path, base.data, base.len);
        q = ngx_sprintf(q, "%V", &value);
        *q = 0;
        value.data = path;
        value.len = q - path;
        
        rc = ngx_file_info(path, &fi);
    
        if (rc == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, path);
             return NGX_ERROR;
        }               
    }
    
    if (rc == NGX_ERROR) {
        printf("can not find correct ts file\n");
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "can not find correct ts file\n");
        return NGX_ERROR;
    }
    
    if (ngx_http_live_ts2jpg_url(r, value, b ,local_addr) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic error!\n");
        return NGX_ERROR;
    }
    return NGX_OK;
}

static ngx_int_t
ngx_http_live_m3u8_create_multi_jpg(ngx_http_request_t *r, ngx_str_t *stream, time_t start, time_t duration, ngx_buf_t *b)
{
    ngx_uint_t                                       size;
    u_char                                          *last, *p, *q, *path, *data,  *buf;
    ngx_file_info_t                                  fi;
    ngx_int_t                                        rc, i;
    size_t                                           root;
    ngx_str_t                                        base, value,  zip_file, number_fill;
    ngx_str_t                                        temp_dir, zip_jpg;
    ngx_fd_t                                         fd;
    ngx_file_info_t                                  info;
    ngx_atomic_uint_t                                temp_num;
    sighandler_t                                     old_handler_zip;

    fd = -1;
    size = 0;

    temp_num = ngx_atomic_fetch_add(ngx_temp_number, 1);

    data = ngx_palloc(r->pool, duration * NGX_LIVE_M3U8_INDEX_LINE_SIZE );
    if (data == NULL) {
        return NGX_ERROR;
    }
    ngx_memzero(data, duration *  NGX_LIVE_M3U8_INDEX_LINE_SIZE );

    last = ngx_http_map_uri_to_path(r, &base, &root, 0);
    if (last == NULL) {
        return NGX_ERROR;
    }
    
    for (p = last - 1; p != base.data; p--) {
        if (*p == '/') {
            break;
        }
    }    
    base.len -= (last - p);

    number_fill.data =  ngx_palloc(r->pool, 10);
    if (number_fill.data == NULL) {
        return NGX_ERROR;
    }  
    ngx_memset(number_fill.data, '0', 10);
	
    last = number_fill.data;
    last = ngx_sprintf(last, "%d", temp_num);
    number_fill.len = 10;
	
    rc = ngx_http_live_m3u8_get_index(r, &base, start, stream, duration, NGX_LIVE, data);
    if (rc == NGX_ERROR) {
        return NGX_ERROR;
    }

    p = data + NGX_LIVE_M3U8_INDEX_LINE_SIZE - 1;
    for ( ; p != data; p--) {
        if (*p == '/') {
            break;
        }
    }
    p ++;
    value.data = data;
    value.len = p - data;

    size = base.len + value.len + 10 + 2 ;
    temp_dir.data = ngx_pnalloc(r->pool,  size );
    if (temp_dir.data == NULL) {
        return NGX_ERROR;
    }
     ngx_memzero(temp_dir.data,  size );

    last = temp_dir.data;
    last = ngx_copy(last, base.data, base.len);
    last = ngx_snprintf(last, value.len, "%V", &value);
    last = ngx_copy(last, number_fill.data, number_fill.len);
    last = ngx_copy(last, "/", 1);
    temp_dir.len = last - temp_dir.data;
    *last = 0;
	
    size = temp_dir.len + sizeof("a.zip");
    zip_file.data = ngx_pnalloc(r->pool,  size);
    if (zip_file.data == NULL) {
        return NGX_ERROR;
    }
     ngx_memzero(zip_file.data,  size );
	 
    last = zip_file.data;
    last = ngx_copy(last, temp_dir.data, temp_dir.len);
    last = ngx_copy(last, "a.zip", sizeof("a.zip")-1);
    zip_file.len = last - zip_file.data;
    *last = 0;

    if ( ngx_http_live_m3u8_create_dir_cmd( r, &temp_dir) != NGX_OK) {   
        return NGX_ERROR;
    }
	
    rc = 0;
    
    for (i = 0, p = data; i < duration; i++, p += NGX_LIVE_M3U8_INDEX_LINE_SIZE) {
        size = base.len + NGX_LIVE_M3U8_INDEX_LINE_SIZE;
        path = ngx_pnalloc(r->pool, size);
        if (path == NULL) {
            return NGX_ERROR;
        }
        
        if (*p == 0x20) {
            continue;
        }

        last = ngx_strlchr(p, p + NGX_LIVE_M3U8_INDEX_LINE_SIZE, ',');
        if (last == NULL) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "replay.txt format error");
			printf("replay.txt error\n");
            return NGX_ERROR;        
        }
        
        value.data = p;
        value.len = last - p;

        q = ngx_copy(path, base.data, base.len);
        q = ngx_sprintf(q, "%V", &value);
        *q = 0;
        value.data = path;
        value.len = q - path;
        
        rc = ngx_file_info(path, &fi);
    
        if (rc == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, ngx_errno, "%s \"%s\" failed", ngx_file_info_n, path);
            continue;
        }
		
        if (rc == NGX_ERROR) {
            printf("can not find correct ts file\n");
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "can not find correct ts file\n");
            return NGX_ERROR;
        }

        if ((rc = ngx_http_live_mutil_ts2jpg(r, value, &zip_file, &temp_dir) ) != NGX_OK) {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get pic or zip error\n");
            continue;
        } 
          
    }

    size = sizeof("/usr/bin/zip  -j "); 
    size += zip_file.len + temp_dir.len +sizeof("*.jpg") + 1;
    zip_jpg.data =  ngx_palloc(r->pool, size);
    if (zip_jpg.data == NULL) {
        goto failed;
    }  
    ngx_memzero(zip_jpg.data, size);
    last = zip_jpg.data;
    last = ngx_copy(last, "/usr/bin/zip  -j ", sizeof("/usr/bin/zip  -j ") - 1);
    last = ngx_copy(last,  zip_file.data, zip_file.len);
    last = ngx_copy(last, " ", 1);
    last = ngx_copy(last, temp_dir.data, temp_dir.len);
    last = ngx_copy(last, "*.jpg", sizeof("*.jpg")-1);
    zip_jpg.len = last - zip_jpg.data;
    *last = 0;

printf("zip_jpg : %s\n", zip_jpg.data);
	
    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) {
    	old_handler_zip= signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_zip_start_cmd(&zip_jpg);
        if (rc == NGX_OK) {	
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "zip ok\n");		
			printf("zip ok\n");
            signal(SIGCHLD, old_handler_zip); 
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "zip error:%d\n", (int) rc);
        signal(SIGCHLD, old_handler_zip); 
    }	
	
    if (i >= FFMPEG_RETRY_TIMES) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get zip try time out of range\n");
        if ( ngx_http_live_m3u8_delete_dir_cmd( r, &temp_dir) != NGX_OK) {
            return NGX_ERROR;
        }
    }

    fd = ngx_open_file(zip_file.data, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
    if (fd == NGX_INVALID_FILE) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "open zip_file error\n");
        printf("open zip_file error\n");
        if ( ngx_http_live_m3u8_delete_dir_cmd( r, &temp_dir) != NGX_OK) {
            printf("delete temp_dir error\n");
            return NGX_ERROR;
        }
        return NGX_ERROR;
    }

    if (ngx_fd_info(fd, &info) == NGX_FILE_ERROR) { 
		printf("open  zip_file info error\n");	
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get zip_file info error\n");
        goto failed;
    }
    
    buf = ngx_palloc(r->pool, info.st_size );
    if (buf == NULL) {
        goto failed;
    }
    ngx_memzero(buf, info.st_size );
    if (read(fd, buf, info.st_size) == -1) { 
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "read zip_file error\n");
        printf("read zip_file error\n");	
        goto failed;
    }
    if (ngx_close_file(fd) == NGX_FILE_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "close zip_file error\n");
		printf("close zip_file error\n");

    }

    if (ngx_delete_file(zip_file.data) == NGX_FILE_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete zip_file error\n");
        printf("delete zip_file error\n");
    }
	
    if ( ngx_http_live_m3u8_delete_dir_cmd( r, &temp_dir) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete temp_dir error\n");
        printf("delete temp_dir error\n");
    }
	
    b->start = buf;
    b->end = buf + info.st_size ;
    b->pos = buf;
    b->last = b->end;
    b->memory = 1;
    b->last_buf = 1;
  
    return NGX_OK;
    
failed:
    
    if (fd != -1) {
        if (ngx_close_file(fd) == NGX_FILE_ERROR) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "close zip_file error\n");
            printf("close zip_file error\n");	
        }
    
        if (ngx_delete_file(zip_file.data) == NGX_FILE_ERROR) 
        {
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete zip_file error\n");
            printf("delete zip_file error\n");	
        }
    }
	
    if ( ngx_http_live_m3u8_delete_dir_cmd( r, &temp_dir) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "delete temp_dir error\n");
        printf("delete temp_dir error\n");
	    return NGX_ERROR;
    }	

	return NGX_ERROR;	
}

ngx_int_t 
ngx_http_share_multi_map_handler(ngx_http_request_t *r)
{
    u_char                                  *p;
    time_t                                    start, len;
    ngx_int_t                                rc;
    ngx_str_t                                value, type;
    ngx_log_t                             *log;
    ngx_buf_t                             *b;
    ngx_chain_t                           out;
    ngx_http_live_m3u8_conf_t   *hlcf;

    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    /* unparsed_uri parse */
    p = r->unparsed_uri.data + r->unparsed_uri.len;
  
    /* type */

    for (; p != r->unparsed_uri.data ; p--) {
       
        if (*p == '.') {
            break;
        }
    }
    if (p == r->unparsed_uri.data) {
        return NGX_HTTP_BAD_REQUEST;
    }
	
    type.data = p + 1;
    type.len = 3;
    if (ngx_strncmp(type.data, (u_char *) "zip", 3)) {
        return NGX_HTTP_BAD_REQUEST;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

    if (r->args.len == 0) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args,bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "start", 5, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args start,bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    start = ngx_atotm(value.data, value.len);

    if (start == NGX_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "start time error , bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (ngx_http_arg(r, (u_char *) "len", 3, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "time len error , bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    len = ngx_atotm(value.data, value.len);
    
    r->root_tested = !r->error_page;

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "buf alloc error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    rc = ngx_http_live_m3u8_create_multi_jpg(r, &hlcf->logo_stream, start, len, b);
    if (rc != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get picture or zip error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }        

    log->action = "sending logo.zip to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);    
}


ngx_int_t 
ngx_http_share_jpg_handler(ngx_http_request_t *r)
{
    time_t                     start, len;
    ngx_int_t                  rc;
    ngx_str_t                  value;
    ngx_log_t                 *log;
    ngx_buf_t                 *b;
    ngx_chain_t                out;
    ngx_http_live_m3u8_conf_t *hlcf;

    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

    if (r->args.len == 0) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args,bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }

    if (ngx_http_arg(r, (u_char *) "start", 5, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args start,bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    start = ngx_atotm(value.data, value.len);

    if (start == NGX_ERROR) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "start time error , bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (ngx_http_arg(r, (u_char *) "len", 3, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "time len error , bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }
    
    len = ngx_atotm(value.data, value.len);
    
    r->root_tested = !r->error_page;

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "buf alloc error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    rc = ngx_http_live_m3u8_create_logo_jpg(r, &hlcf->logo_stream, start, len, b);
    if (rc != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get picture error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }        

    log->action = "sending logo.jpg to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);    
}

ngx_int_t 
ngx_http_get_pic_handler(ngx_http_request_t *r)
{
	time_t					   starttime;
	ngx_int_t				   rc;
	ngx_str_t				   value;
	ngx_log_t				  *log;
	ngx_buf_t				  *b;
	ngx_chain_t 			   out;
	ngx_http_live_m3u8_conf_t *hlcf;

	if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }
	
    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

   	if (r->args.len == 0) {
	    ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args,bad request\n");
	    return NGX_HTTP_BAD_REQUEST;
    }

	if (ngx_http_arg(r, (u_char *) "starttime", 9, &value) != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "url have no args start,bad request\n");
        return NGX_HTTP_BAD_REQUEST;
    }

    if(1 == value.len && '0' == *(value.data) ){
		starttime = 0;	
    }
	else{
		//starttime = ngx_http_live_m3u8_timestamp(&value, hlcf->time_offset);
		starttime = ngx_atotm(value.data, value.len);
		if (starttime == NGX_ERROR) {
			ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "start time error for get pic , bad request\n");
			return NGX_HTTP_BAD_REQUEST;
		}
      
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get_pic starttime=%lld\n", starttime);	
	}

	r->root_tested = !r->error_page;

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "buf alloc error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

	rc = ngx_http_live_m3u8_create_pic_jpg(r, &hlcf->logo_stream, &hlcf->local_addr, starttime, b);
    
    if (rc != NGX_OK) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "get picture error , internal error\n");
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }        

    log->action = "sending pic to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);    
}

static ngx_int_t
ngx_http_share_dynamic_offset(ngx_http_request_t *r, ngx_int_t *offset)
{
    u_char                    *last;
    size_t                     root;
    ngx_int_t                  rc;
    ngx_uint_t                 i;
    ngx_str_t                  path, value;
    ngx_log_t                 *log;
    u_char                    *file, *buf;
    ngx_http_live_m3u8_conf_t *hlcf;
    ngx_fd_t                   fd;
    ngx_file_info_t            info;

    fd = -1;   
    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);

    last = ngx_http_map_uri_to_path(r, &path, &root, 0);
    if (last == NULL) {
        return NGX_ERROR;
    }

    rc = NGX_ERROR;
    log = r->connection->log;

    path.len = last - path.data;
    path.len -= 5;
    
    file = ngx_palloc(r->pool, path.len + hlcf->logo_stream.len + 6);
    if (file == NULL) {
        return NGX_ERROR;
    }
 
    last = ngx_copy(file, path.data, path.len);
    last = ngx_copy(last, hlcf->logo_stream.data, hlcf->logo_stream.len);
    last = ngx_copy(last, (u_char *) ".m3u8", 5);
    *last = 0;
    
    fd = ngx_open_file(file, NGX_FILE_RDONLY, NGX_FILE_OPEN, 0);
    if (fd == NGX_INVALID_FILE) {
        ngx_log_error(NGX_LOG_EMERG, log, ngx_errno, ngx_open_file_n " \"%s\" failed", file);
        return NGX_ERROR;
    }

    if (ngx_fd_info(fd, &info) == NGX_FILE_ERROR) {
        ngx_log_error(NGX_LOG_EMERG, log, ngx_errno, ngx_fd_info_n " \"%s\" failed", file);
        goto done;
    }
    
    buf = ngx_palloc(r->pool, info.st_size);
    if (file == buf) {
        goto done;
    }
    
    if (read(fd, buf, info.st_size) != info.st_size) {
        ngx_log_error(NGX_LOG_CRIT, log, ngx_errno, "read() \"%s\" failed", file);
        goto done;
    }
    
    /* get last file simply (TODO) */
    last = buf + info.st_size;
    
    for (i = 1; i < 4; i++) {
        if (*(last - i) == 's') {
            break;
        }
    }
    
    if (i == 4) {
        goto done;
    }
    
    last -= i;
    last -= (18 - 1); /* 20160115T165247.ts */
    
    value.data = last;
    value.len = 15;
    
    rc = ngx_http_live_m3u8_timestamp(&value, 0);
    if (rc == NGX_ERROR) {
        goto done;
    }
    
    *offset = rc - ngx_time();
//    rc = NGX_OK;

done:    
    if (fd != -1) {
        ngx_close_file(fd);
    }
    
    return rc;
}

static ngx_int_t
ngx_http_live_m3u8_create_dir_cmd(ngx_http_request_t *r, ngx_str_t *cmd)
{
    ngx_int_t                  rc, i;
    sighandler_t              old_handler_mkdir;
    ngx_str_t                  create_cmd;
    u_char                    *last;

    i = cmd->len + sizeof("mkdir -m 777 ") ;
    create_cmd.data =  ngx_palloc(r->pool, i);
    if (create_cmd.data == NULL) {
        return NGX_ERROR;
    }  
    ngx_memzero(create_cmd.data, i);

    last = create_cmd.data;
    last = ngx_copy(last, "mkdir -m 777 ", sizeof("mkdir -m 777 ") - 1);
    last = ngx_copy(last, cmd->data, cmd->len);
    create_cmd.len = last - create_cmd.data;
    *last = 0;

    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) {
    	old_handler_mkdir= signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_start_cmd(&create_cmd);
        if (rc == NGX_OK) {	
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir mk ok\n");		
			printf("temp_dir mk ok\n");
            signal(SIGCHLD, old_handler_mkdir); 
            break;
        }
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir mk error:%d\n", (int) rc);
        printf("temp_dir mk error\n");
        signal(SIGCHLD, old_handler_mkdir); 
    }


    if (i >= FFMPEG_RETRY_TIMES) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir mk try time out of range\n");
        return NGX_ERROR;
    }

    return NGX_OK;

}

static ngx_int_t
ngx_http_live_m3u8_delete_dir_cmd(ngx_http_request_t *r, ngx_str_t *cmd)
{
    ngx_int_t                  rc, i;
    sighandler_t              old_handler_mkdir;
    ngx_str_t                  create_cmd;
    u_char                    *last;


    i = cmd->len + sizeof("rm -rf ")  ;
    create_cmd.data =  ngx_palloc(r->pool, i);
    if (create_cmd.data == NULL) {
        return NGX_ERROR;
    }  
    ngx_memzero(create_cmd.data, i);

    last = create_cmd.data;
    last = ngx_copy(last, "rm -rf ", sizeof("rm -rf ") - 1);
    last = ngx_copy(last, cmd->data, cmd->len);
    create_cmd.len = last - create_cmd.data;
    *last = 0;

    for (i = 0; i < FFMPEG_RETRY_TIMES; i++) {
    	old_handler_mkdir= signal(SIGCHLD, SIG_DFL);  
        
        rc = ngx_http_live_m3u8_start_cmd(&create_cmd);
        if (rc == NGX_OK) {	
            ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir rm -rf  ok\n");		
			printf("temp_dir rm -rf  ok\n");
            signal(SIGCHLD, old_handler_mkdir); 
            break;
        }
		ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir rm -rf error:%d\n", (int) rc);
        signal(SIGCHLD, old_handler_mkdir); 
    }


    if (i >= FFMPEG_RETRY_TIMES) {
        ngx_log_error(NGX_LOG_ERR, r->connection->log, 0, "temp_dir rm -rf  try time out of range\n");
        return NGX_ERROR;
    }
    return NGX_OK;
}



