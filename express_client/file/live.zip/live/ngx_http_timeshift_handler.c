#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_http_live_m3u8.h>


typedef struct {
    u_char                           color;
    u_char                           dummy[3];
    ngx_queue_t                      queue;
    time_t                           start;
    time_t                           offset;
} ngx_http_timeshift_req_node_t;


typedef struct {
    ngx_rbtree_t                     rbtree;
    ngx_rbtree_node_t                sentinel;
    ngx_queue_t                      queue;
    
    ngx_atomic_t                     session_counter;
} ngx_http_timeshift_req_shctx_t;


typedef struct {
    ngx_http_timeshift_req_shctx_t  *sh;
    ngx_slab_pool_t                 *shpool;
    ngx_str_t                        name;
    ngx_http_timeshift_req_node_t   *node;
} ngx_http_timeshift_req_ctx_t;


static ngx_int_t ngx_http_timeshift_init_zone(ngx_shm_zone_t *shm_zone, void *data);
static ngx_http_timeshift_req_node_t * ngx_http_timeshift_req_lookup(ngx_http_timeshift_req_ctx_t *ctx, ngx_uint_t hash);
static ngx_int_t ngx_http_timeshift_req_insert(ngx_http_timeshift_req_ctx_t *ctx, ngx_uint_t hash, time_t start);
static void ngx_http_timeshift_req_expire(ngx_http_timeshift_req_ctx_t *ctx);

char *
ngx_http_live_m3u8_timeshift_zone(ngx_conf_t *cf, ngx_command_t *cmd, 
    void *conf)
{
    u_char                            *p;
    ssize_t                            size;
    ngx_str_t                         *value, name, s;
    ngx_uint_t                         i;
    ngx_shm_zone_t                    *shm_zone;
    ngx_http_timeshift_req_ctx_t      *ctx;

    value = cf->args->elts;

    ctx = ngx_pcalloc(cf->pool, sizeof(ngx_http_timeshift_req_ctx_t));
    if (ctx == NULL) {
        return NGX_CONF_ERROR;
    }

    size = 0;
    name.len = 0;

    for (i = 1; i < cf->args->nelts; i++) {

        if (ngx_strncmp(value[i].data, "zone=", 5) == 0) {

            name.data = value[i].data + 5;

            p = (u_char *) ngx_strchr(name.data, ':');

            if (p == NULL) {
                ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "invalid zone size \"%V\"", &value[i]);
                return NGX_CONF_ERROR;
            }

            name.len = p - name.data;

            s.data = p + 1;
            s.len = value[i].data + value[i].len - s.data;

            size = ngx_parse_size(&s);

            if (size == NGX_ERROR) {
                ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "invalid zone size \"%V\"", &value[i]);
                return NGX_CONF_ERROR;
            }

            if (size < (ssize_t) (8 * ngx_pagesize)) {
                ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "zone \"%V\" is too small", &value[i]);
                return NGX_CONF_ERROR;
            }

            continue;
        }

        /* reserved for other parameters */

        ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "invalid parameter \"%V\"", &value[i]);
        return NGX_CONF_ERROR;
    }

    if (name.len == 0) {
        ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "\"%V\" must have \"zone\" parameter", &cmd->name);
        return NGX_CONF_ERROR;
    }

    ctx->name = name;
    shm_zone = ngx_shared_memory_add(cf, &name, size, &ngx_http_live_m3u8_module);
    if (shm_zone == NULL) {
        return NGX_CONF_ERROR;
    }

    if (shm_zone->data) {
        ngx_conf_log_error(NGX_LOG_EMERG, cf, 0, "duplicate zone \"%V\"", &name);
        return NGX_CONF_ERROR;
    }

    shm_zone->init = ngx_http_timeshift_init_zone;
    shm_zone->data = ctx;

    return NGX_CONF_OK;
}


ngx_int_t 
ngx_http_timeshift_handler(ngx_http_request_t *r)
{
    u_char                          *last;
    time_t                           now, start, len;
    size_t                           root;
    ngx_int_t                        rc, hash, sequence;
    ngx_uint_t                       level;
    ngx_str_t                        path, stream, value;
    ngx_log_t                       *log;
    ngx_buf_t                       *b;
    ngx_chain_t                      out;
    ngx_open_file_info_t             of;
    ngx_http_core_loc_conf_t        *clcf;
    ngx_http_live_m3u8_conf_t       *hlcf;
    ngx_http_timeshift_req_ctx_t    *ctx;
    ngx_http_timeshift_req_node_t   *tr;

    if (!(r->method & (NGX_HTTP_GET|NGX_HTTP_HEAD))) {
        return NGX_HTTP_NOT_ALLOWED;
    }

    if (r->uri.data[r->uri.len - 1] == '/') {
        return NGX_DECLINED;
    }

    rc = ngx_http_discard_request_body(r);

    if (rc != NGX_OK) {
        return rc;
    }

    hlcf = ngx_http_get_module_loc_conf(r, ngx_http_live_m3u8_module);
    log = r->connection->log;

    if (r->args.len == 0) {
        return NGX_HTTP_BAD_REQUEST;
    }

    r->root_tested = !r->error_page;
    ctx = hlcf->shm_zone->data;
    now = ngx_time();

    b = ngx_pcalloc(r->pool, sizeof(ngx_buf_t));
    if (b == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_test_stream_type(r, &hlcf->metas, &stream)) {

        goto meta;

    } else if (ngx_http_test_stream_type(r, &hlcf->streams, &stream)) {
        
        if (ngx_http_arg(r, (u_char *) "session", 7, &value) != NGX_OK) {
            /* todo: create new session & return 302 */
            return NGX_HTTP_BAD_REQUEST;
        }

        /* lookup & build playlist */
        hash = ngx_atoi(value.data, value.len);
        if (hash == NGX_ERROR) {
            return NGX_HTTP_BAD_REQUEST;
        }

        ngx_shmtx_lock(&ctx->shpool->mutex);
        tr = ngx_http_timeshift_req_lookup(ctx, hash);
 
        if (tr == NULL) {
            /* expired node or mocked request */
            ngx_shmtx_unlock(&ctx->shpool->mutex);
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }

        /* simple realization */
        /* TODO: precise 'sequence' */

        start = tr->start + tr->offset;
        sequence = (now - start) / hlcf->segment_duration;
        start = tr->start + sequence * hlcf->segment_duration;

        len = hlcf->segment_duration * hlcf->segments_per_playlist;

        ngx_queue_remove(&tr->queue);
        ngx_queue_insert_head(&ctx->sh->queue, &tr->queue);
        
        ngx_shmtx_unlock(&ctx->shpool->mutex);

        rc = ngx_http_live_m3u8_build_live_playlist(r, b, &stream, start, len, sequence);

        if (rc == NGX_ERROR) {
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }
        r->headers_out.last_modified_time = now;
        goto done;
    } else {

        return NGX_DECLINED;
    }

meta:

    if (ngx_http_arg(r, (u_char *) "starttime", 9, &value) != NGX_OK) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    start = ngx_http_live_m3u8_timestamp(&value, hlcf->time_offset);

    if (start == NGX_ERROR) {
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (start >= now) {
        /* live streaming */
        return NGX_HTTP_BAD_REQUEST;
    }
    
    if (start < NGX_LIVE_MEU8_MAX_TIME) {
        start = NGX_LIVE_MEU8_MAX_TIME;
    }
    
    /* create new session and return index with session id */
    hash = ctx->sh->session_counter;
    (void) ngx_atomic_fetch_add(&ctx->sh->session_counter, 1);
    ngx_shmtx_lock(&ctx->shpool->mutex);
    rc =  ngx_http_timeshift_req_insert(ctx, hash, start);
    ngx_shmtx_unlock(&ctx->shpool->mutex);
    ngx_log_debug2(NGX_LOG_DEBUG_HTTP, log, 0, "timeshift[%ui]: %i %ui.%03ui", hash, rc);

    if (rc != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
     
    last = ngx_http_map_uri_to_path(r, &path, &root, 0);
    if (last == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    path.len = last - path.data;

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, log, 0, "http timeshift filename: \"%V\"", &path);
    clcf = ngx_http_get_module_loc_conf(r, ngx_http_core_module);
    ngx_memzero(&of, sizeof(ngx_open_file_info_t));

    of.read_ahead = clcf->read_ahead;
    of.directio = clcf->directio;
    of.valid = clcf->open_file_cache_valid;
    of.min_uses = clcf->open_file_cache_min_uses;
    of.errors = clcf->open_file_cache_errors;
    of.events = clcf->open_file_cache_events;

    if (ngx_http_set_disable_symlinks(r, clcf, &path, &of) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_open_cached_file(clcf->open_file_cache, &path, &of, r->pool) != NGX_OK)
    {
        switch (of.err) {

        case 0:
            return NGX_HTTP_INTERNAL_SERVER_ERROR;

        case NGX_ENOENT:
        case NGX_ENOTDIR:
        case NGX_ENAMETOOLONG:

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_NOT_FOUND;
            break;

        case NGX_EACCES:
#if (NGX_HAVE_OPENAT)
        case NGX_EMLINK:
        case NGX_ELOOP:
#endif

            level = NGX_LOG_ERR;
            rc = NGX_HTTP_FORBIDDEN;
            break;

        default:

            level = NGX_LOG_CRIT;
            rc = NGX_HTTP_INTERNAL_SERVER_ERROR;
            break;
        }

        if (rc != NGX_HTTP_NOT_FOUND || clcf->log_not_found) {
            ngx_log_error(level, log, of.err, "%s \"%s\" failed", of.failed, path.data);
        }

        return rc;
    }

    if (!of.is_file) {

        if (ngx_close_file(of.fd) == NGX_FILE_ERROR) {
            ngx_log_error(NGX_LOG_ALERT, log, ngx_errno, ngx_close_file_n " \"%s\" failed", path.data);
        }

        return NGX_DECLINED;
    }

    len = sizeof("session=") - 1;
    len += 32;
    value.data = ngx_palloc(r->pool, len);
    if (value.data == NULL) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    last = ngx_sprintf(value.data, "session=%d", hash);
    value.len = last - value.data;

    rc = ngx_http_live_m3u8_build_index(r, &of, &value, b);
    
    if (rc == NGX_ERROR){        
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->headers_out.last_modified_time = of.mtime;

done:

    log->action = "sending live_m3u8 to client";

    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = ngx_buf_size(b);

    if (ngx_http_set_etag(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    if (ngx_http_set_content_type(r) != NGX_OK) {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }

    r->allow_ranges = 1;

    rc = ngx_http_send_header(r);

    if (rc == NGX_ERROR || rc > NGX_OK || r->header_only) {
        return rc;
    }

    out.buf = b;
    out.next = NULL;

    return ngx_http_output_filter(r, &out);
}


static void
ngx_http_timeshift_rbtree_insert_value(ngx_rbtree_node_t *temp, ngx_rbtree_node_t *node, ngx_rbtree_node_t *sentinel)
{
    ngx_rbtree_node_t  **p;

    for ( ;; ) {

        /*  node->key < temp->key */

        p = ((ngx_rbtree_key_int_t) (node->key - temp->key) < 0)
            ? &temp->left : &temp->right;

        if (*p == sentinel) {
            break;
        }

        temp = *p;
    }

    *p = node;
    node->parent = temp;
    node->left = sentinel;
    node->right = sentinel;
    ngx_rbt_red(node);
}


static ngx_int_t
ngx_http_timeshift_init_zone(ngx_shm_zone_t *shm_zone, void *data)
{
    ngx_http_timeshift_req_ctx_t  *octx = data;

    size_t                         len;
    ngx_http_timeshift_req_ctx_t  *ctx;

    ctx = shm_zone->data;

    if (octx) {

        if (ngx_strcmp(ctx->name.data, octx->name.data) != 0) {
            ngx_log_error(NGX_LOG_EMERG, shm_zone->shm.log, 0,
                          "timeshift \"%V\" uses the \"%V\" name "
                          "while previously it used the \"%V\" name",
                          &shm_zone->shm.name, &ctx->name,
                          &octx->name);

            return NGX_ERROR;
        }

        ctx->sh = octx->sh;
        ctx->shpool = octx->shpool;

        return NGX_OK;
    }

    ctx->shpool = (ngx_slab_pool_t *) shm_zone->shm.addr;

    if (shm_zone->shm.exists) {
        ctx->sh = ctx->shpool->data;

        return NGX_OK;
    }

    ctx->sh = ngx_slab_alloc(ctx->shpool, sizeof(ngx_http_timeshift_req_shctx_t));
    if (ctx->sh == NULL) {
        return NGX_ERROR;
    }

    ctx->shpool->data = ctx->sh;

    ngx_rbtree_init(&ctx->sh->rbtree, &ctx->sh->sentinel, ngx_http_timeshift_rbtree_insert_value);

    ngx_queue_init(&ctx->sh->queue);

    len = sizeof(" in timeshift zone \"\"") + shm_zone->shm.name.len;

    ctx->shpool->log_ctx = ngx_slab_alloc(ctx->shpool, len);
    if (ctx->shpool->log_ctx == NULL) {
        return NGX_ERROR;
    }

    ngx_sprintf(ctx->shpool->log_ctx, " in timeshift zone \"%V\"%Z", &shm_zone->shm.name);
    ctx->shpool->log_nomem = 0;

    return NGX_OK;
}


static ngx_http_timeshift_req_node_t * 
ngx_http_timeshift_req_lookup(ngx_http_timeshift_req_ctx_t *ctx, ngx_uint_t hash)
{
    ngx_rbtree_node_t               *node, *sentinel;
    ngx_http_timeshift_req_node_t   *trn;

    node = ctx->sh->rbtree.root;
    sentinel = ctx->sh->rbtree.sentinel;

    while (node != sentinel) {

        if (hash < node->key) {
            node = node->left;
            continue;
        }

        if (hash > node->key) {
            node = node->right;
            continue;
        }

        /* hash == node->key */

        trn = (ngx_http_timeshift_req_node_t *) &node->color;

        return trn;
    }

    return NULL;
}


static ngx_int_t 
ngx_http_timeshift_req_insert(ngx_http_timeshift_req_ctx_t *ctx, ngx_uint_t hash, time_t start)
{
    size_t                          size;
    ngx_rbtree_node_t              *node;
    ngx_http_timeshift_req_node_t  *tr;

    size = offsetof(ngx_rbtree_node_t, color)
           + sizeof(ngx_http_timeshift_req_node_t);

    node = ngx_slab_alloc_locked(ctx->shpool, size);

    if (node == NULL) {
        ngx_http_timeshift_req_expire(ctx);

        node = ngx_slab_alloc_locked(ctx->shpool, size);
        if (node == NULL) {
            ngx_log_error(NGX_LOG_ALERT, ngx_cycle->log, 0, "could not allocate node%s", ctx->shpool->log_ctx);
            return NGX_ERROR;
        }
    }

    node->key = hash;

    tr = (ngx_http_timeshift_req_node_t *) &node->color;
    tr->start = start;
    tr->offset = ngx_time() - start;

    ngx_rbtree_insert(&ctx->sh->rbtree, node);

    ngx_queue_insert_head(&ctx->sh->queue, &tr->queue);

    ctx->node = tr;

    return NGX_OK;
}


static void 
ngx_http_timeshift_req_expire(ngx_http_timeshift_req_ctx_t *ctx)
{
    ngx_queue_t                    *q;
    ngx_rbtree_node_t              *node;
    ngx_http_timeshift_req_node_t  *tr;

    if (ngx_queue_empty(&ctx->sh->queue)) {
        return;
    }

    q = ngx_queue_last(&ctx->sh->queue);
    tr = ngx_queue_data(q, ngx_http_timeshift_req_node_t, queue);

    ngx_queue_remove(q);

    node = (ngx_rbtree_node_t *)
               ((u_char *) tr - offsetof(ngx_rbtree_node_t, color));

    ngx_rbtree_delete(&ctx->sh->rbtree, node);

    ngx_slab_free_locked(ctx->shpool, node);
}
